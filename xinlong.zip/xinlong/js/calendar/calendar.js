/*
// @author : lael
// blog : http://hi.baidu.com/lael80
// http://www.gzyd.net
// all right reserved.
*/
/*
<input onclick="calendar_init(this.id, this.value, 'Y-m-d H:i:s')" name="datetime" type="text" id="datetime" />

<link href="{$CFG[skinpath]}javascript/dialog/dialog.css" type="text/css" rel="stylesheet">
<script language="javascript" src="{$CFG[skinpath]}javascript/dialog/dialog.js"></script>
<script language="javascript" src="{$CFG[skinpath]}javascript/dateutils.js"></script>
<link href="{$CFG[skinpath]}javascript/calendar/calendar.css" type="text/css" rel="stylesheet">
<script language="javascript" src="{$CFG[skinpath]}javascript/calendar/calendar.js"></script>
<script language="javascript">
var _dialog = new dialog('{$CFG[skinpath]}javascript/dialog/');
var _dateutils = new dateutils();
var _calendar = new calendar();
</script>
*/
//全局函数
function calendar_click(objid, y, m, d, f){
	var hh = $('calendar_hh').value;
	var ii = $('calendar_ii').value;
	var ss = $('calendar_ss').value;
	$(objid).value = _dateutils.format(y + '-' + m + '-' + d + ' ' + hh + ':' + ii + ':' + ss, 'Y-m-d H:i:s', f);
	calendar_close();
}
function calendar_init(objid, d, f, st){
	_dialog.create('dl_calendar', '日期时间', _calendar.create(objid, d, f), 228, false, 0, false, objid, st ? st : 0, 0, 0);
}
function calendar_chgyear(objid, d, f, y){
	var datetime = _dateutils.newdate(d, f);
	calendar_init(objid, _calendar.getnext(d, f, y, datetime.getMonth() + 1), f, 100);
}
function calendar_chgmonth(objid, d, f, m){
	var datetime = _dateutils.newdate(d, f);
	calendar_init(objid, _calendar.getnext(d, f, datetime.getFullYear(), m), f, 100);
}
function calendar_chgtime(hh, ii, ss){
	$('calendar_hh').value = hh;
	$('calendar_ii').value = ii;
	$('calendar_ss').value = ss;
}
function calendar_close(){
	_dialog.close('dl_calendar', false, 0);
}
//日期时间控件类开始
var calendar = function(){}

calendar.prototype.create = function(objid, d, f){
	var datetime = _dateutils.newdate(d, f);
	var start = this.getstart(datetime.getFullYear(), datetime.getMonth() + 1);
	var days = this.getdays(datetime.getFullYear(), datetime.getMonth() + 1);
	var cells = new Array;
	for(var i = 0; i < start; i ++)cells[cells.length] = '&nbsp;';
	for(var i = start; i <= days + start - 1; i ++)cells[cells.length] = i - start + 1;
	var end = 7 - cells.length % 7;
	if(end < 7)for(var i = 0; i < end; i ++)cells[cells.length] = '&nbsp;';
	
	var todaydt = new Date();

	var weeks = ['日','一','二','三','四','五','六'];
	html = '<table align="center" class="calendar_table"><tr>';
	html += '<td colspan="7" class="today" ';
	html += 'onclick="calendar_chgtime(\'' + todaydt.getHours() + '\', \'' + todaydt.getMinutes() + '\', \'' + todaydt.getSeconds() + '\');calendar_click(\'' + objid + '\', \'' + todaydt.getFullYear() + '\', \'' + (todaydt.getMonth() + 1) + '\', \'' + todaydt.getDate() + '\', \'' + _dateutils.addslashes(f) + '\')">';
	html += _dateutils.format(todaydt, false, f) + '</td></tr><tr><td colspan="7" class="control">';
	html += '<span title="前一年" onclick="calendar_init(\'' + objid + '\', \'' + this.getnext(d, f, datetime.getFullYear() - 1, datetime.getMonth() + 1) + '\', \'' + _dateutils.addslashes(f) + '\', 100)">&laquo;</span>';
	html += '<input type="text" style="width:40px;" title="可直接修改年份，按回车键确定" value="' + datetime.getFullYear() + '" onchange="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getFullYear() + '\';};calendar_chgyear(\'' + objid + '\', \'' + d + '\', \'' + _dateutils.addslashes(f) + '\', this.value)" onkeydown="if(event.keyCode==13){calendar_chgyear(\'' + objid + '\', \'' + d + '\', \'' + _dateutils.addslashes(f) + '\', this.value);}else{if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getFullYear() + '\';}}" onkeyup="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getFullYear() + '\';}" />';
	html += '年<span title="后一年" onclick="calendar_init(\'' + objid + '\', \'' + this.getnext(d, f, datetime.getFullYear() + 1, datetime.getMonth() + 1) + '\', \'' + _dateutils.addslashes(f) + '\', 100)">&raquo;</span>-';
	html += '<span title="上个月" onclick="calendar_init(\'' + objid + '\', \'' + this.getnext(d, f, datetime.getFullYear(), datetime.getMonth() + 1 - 1) + '\', \'' + _dateutils.addslashes(f) + '\',100)">&laquo;</span>';
	html += '<input type="text" style="width:20px;" title="可直接修改月份，按回车键确定" class="month" value="' + (datetime.getMonth() + 1) + '" onchange="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + (datetime.getMonth() + 1) + '\';};calendar_chgmonth(\'' + objid + '\', \'' + d + '\', \'' + _dateutils.addslashes(f) + '\', this.value)" onkeydown="if(event.keyCode==13){calendar_chgmonth(\'' + objid + '\', \'' + d + '\', \'' + _dateutils.addslashes(f) + '\', this.value);}else{if(!/^[0-9]+$/.test(this.value)){this.value=\'' + (datetime.getMonth() + 1) + '\';}}" onkeyup="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + (datetime.getMonth() + 1) + '\';}" />';
	html += '月<span title="下个月" onclick="calendar_init(\'' + objid + '\', \'' + this.getnext(d, f, datetime.getFullYear(), datetime.getMonth() + 1 + 1) + '\', \'' + _dateutils.addslashes(f) + '\', 100)">&raquo;</span>';
	html += '</td></tr><tr>';
	for(var i = 0; i < 7; i++) {html += '<th>'+weeks[i]+'</th>';}
	html += '</tr>';
	for(var i = 0; i < cells.length; i++) {
		if(i%7 == 0) html += '<tr>';
		html += '<td onmouseover="this.style.backgroundColor=\'#FFCC99\';" onmouseout="this.style.backgroundColor=\'#FFFFFF\';"';
		if(cells[i] == '&nbsp;'){
			html += ' onclick="calendar_close()"';
		}else{
			html += ' onclick="calendar_click(\'' + objid + '\', \'' + datetime.getFullYear() + '\', \'' + (datetime.getMonth() + 1) + '\', \'' + cells[i] + '\', \'' + _dateutils.addslashes(f) + '\')"';
		}
		if((datetime.getDate() == cells[i]) || (datetime.getFullYear() == todaydt.getFullYear() && datetime.getMonth() == todaydt.getMonth() && todaydt.getDate() == cells[i])){
			html += ' class="selected"';
		}
		html += '> '+cells[i]+' </td>';
		if(i%7 == 6) html += '</tr>';
	}
/*	html += '<tr><td colspan="7" class="time">';
	html += '<input type="text" id="calendar_hh" maxlength="2" value="' + datetime.getHours() + '" onchange="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getHours() + '\';}" onkeydown="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getHours() + '\';}" onkeyup="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getHours() + '\';}" />时';
	html += '<input type="text" id="calendar_ii" maxlength="2" value="' + datetime.getMinutes() + '" onchange="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getMinutes() + '\';}" onkeydown="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getMinutes() + '\';}" onkeyup="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getMinutes() + '\';}" />分';
	html += '<input type="text" id="calendar_ss" maxlength="2" value="' + datetime.getSeconds() + '" onchange="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getSeconds() + '\';}"onkeydown="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getSeconds() + '\';}" onkeyup="if(!/^[0-9]+$/.test(this.value)){this.value=\'' + datetime.getSeconds() + '\';}" />秒';
	html += '</td></tr>'; */
	html += '</table>';
	return html;
	
}
calendar.prototype.getnext = function(d, f, y, m){
	var datetime = _dateutils.newdate(d, f);
	if(y > 2099 || y < 1970)y = datetime.getFullYear();
	if(m > 12)m = 1;
	if(m < 1)m = 12;
	datetime = new Date(y, m - 1, datetime.getDate(), datetime.getHours(), datetime.getMinutes(), datetime.getSeconds());
	return _dateutils.format(datetime, false, f);
}
calendar.prototype.getstart = function(y, m){
	var d = new Date(y, m - 1, 1);
	return d.getDay();
}
calendar.prototype.getdays = function(y, m){
	var d = new Date(y, m, 1);
	d = new Date(d - (24*60*60*1000));
	return d.getDate();
}