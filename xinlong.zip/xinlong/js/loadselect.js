var loadselect_setTimeout = {};
function loadselect(o){
	$(o).style.visibility = 'hidden';
	var onchangefunc = $(o).getAttribute('_onchange');
	if(!onchangefunc)onchangefunc = '';
	var d = document.createElement('DIV');
	d.id = 'loadselect_selected_' + o;
	d.className = 'loadselect_selected';
	d.style.width = ($(o).offsetWidth + 12) + 'px';
	d.style.height = ($(o).offsetHeight + 5) + 'px';
	d.style.lineHeight = d.style.height;
	$(o).parentNode.appendChild(d);
	d.innerHTML = $(o).options[$(o).selectedIndex].innerHTML;
	
	var s = document.createElement('DIV');
	s.id = 'loadselect_' + o;
	s.className = 'loadselect';
	s.style.width = ($(o).offsetWidth + 24) + 'px';
	//s.style.height = ($(o).offsetHeight + 6) + 'px';
	s.style.display = '';
	s.style.overflow = 'hidden';
	$(o).parentNode.appendChild(s);
	s.innerHTML = '<ul>';
	for(var i = 0; i < $(o).options.length; i ++){
		var e = '';
		if(i == 0)e = 'first';
		if(i == $(o).options.length - 1)e = 'end';
		if(1 == $(o).options.length)e = 'one';
		s.innerHTML += '<li><a class="' + e + '" style="padding:3px; line-height:150%;" href="javascript:void(0)" onfocus="this.blur();" onclick="loadselect_click(this, \'' + o + '\', ' + i + ');' + onchangefunc + '">' + $(o).options[i].innerHTML + '</a></li>';
	}	
	s.innerHTML += '</ul>';
	var sh = s.offsetHeight;
	var dh = d.offsetHeight;
	s.style.display = 'none';
	//s.style.top = '-' + (sh * 1 - dh * 1) + 'px';//���ϵ���ȡ��ע��

	s.onmouseout = function(){
		loadselect_setTimeout[o] = setTimeout(function(){$('loadselect_' + o).style.display = 'none'}, 800);
	}
	s.onmouseover = function(){
		try{clearTimeout(loadselect_setTimeout[o]);}catch(e){}
		$('loadselect_' + o).style.display = '';
	}
	
	d.onclick = function(){
		try{clearTimeout(loadselect_setTimeout[o]);}catch(e){}
		$('loadselect_' + o).style.display = '';
	}
}
function loadselect_click(a, o, v){
	try{clearTimeout(loadselect_setTimeout[o]);}catch(e){}
	$(o).selectedIndex = v;
	$('loadselect_' + o).style.display = 'none';
	$('loadselect_selected_' + o).innerHTML = $(a).innerHTML;
}