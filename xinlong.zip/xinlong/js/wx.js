﻿function TestCheck(){
	alert("test");
	WxMpInMemoryConfigStorage config = new WxMpInMemoryConfigStorage();
	config.setAppId("wx8bc2f809b9d25722"); // 设置微信公众号的appid
	config.setSecret("01080b1b872f49f576bca70e9f447281"); // 设置微信公众号的app corpSecret
	config.setToken("ruanstd2017"); // 设置微信公众号的token
	config.setAesKey("k5XGEu6ZrJ8oyZmlLKIGc5NkE4NeBFykk86JT5B6JxO"); // 设置微信公众号的EncodingAESKey
	
	WxMpServiceImpl wxService = new WxMpServiceImpl();
	wxService.setWxMpConfigStorage(config);
	
	// 用户的openid在下面地址获得 
	// https://mp.weixin.qq.com/debug/cgi-bin/apiinfo?t=index&type=用户管理&form=获取关注者列表接口%20/user/get 
	String openid = "oQvfN1csMNB7irD7FrUCdUUE91UM";
	WxMpCustomMessage message = WxMpCustomMessage.TEXT().toUser(openid).content("Hello World").build();
	wxService.customMessageSend(message);
}


