/*
// @author : lael
// blog : http://hi.baidu.com/lael80
// http://www.gzyd.net
// all right reserved.
*/
//全局变量
var dialog_object = {};
var dialog_isie = window.navigator.userAgent.indexOf("MSIE") != -1;
var dialog_dgX = dialog_dgY = 0;       
var dialog_dgdiv;
//对话框类
var dialog = function(_path, _skin){
	this.path = _path ? _path : 'javascript/dialog/';
	this.skin = _skin ? _skin : 'blue';
}
//对话框id, 标题ti，内容cc，w、h;宽、高，ty:0,1,2类型（普通、alert、confim），mk:id/false显示庶罩层，依附对象ob:id/false显示，st:0-100渐变显示，ct:0-*多少毫秒后自动关闭, cst:关闭对话框时渐变0-100（未设置时值等于st）
/*
<link href="javascript/dialog/dialog.css" type="text/css" rel="stylesheet">
<script language="javascript" src="javascript/dialog/dialog.js"></script>
<script language="javascript">
var _dialog = new dialog('javascript/dialog/');
var d1 = _dialog.create('test1', 'test1', '内容1111111111111<br /><br />', 500, false, 1, 'test1make1', 'o', 0, 0);
var d2 = _dialog.create('test2', 'test2', '内容2222222222222', 300, false, 2, false, false, 0, 0);
//事件
_dialog.event(d1, 'onclose', function(){alert('close');});
_dialog.event(d2, 'onyes', function(){alert('yes');});
_dialog.event(d2, 'onno', function(){alert('no');_dialog.close('test1', 'test1make1', 100, true);});
</script>
*/
dialog.prototype.create = function(id, ti, cc, w, h, ty, mk, ob, st, ct, cst){
	//默认值
	id = id || 'dialog';
	ty = ty || 0;
	ob = ob ? $(ob) : false;
	st = st == 0 ? st : (st || 100);
	cst = typeof(cst) == 'undefined' ? st : cst;
	ct = ct || 0;
	
	var doc = document.documentElement || document.body;
	var cw = parseInt(doc.clientWidth);
	var ch = parseInt(doc.clientHeight);
	var sw = parseInt(doc.scrollWidth);
	var sh = parseInt(doc.scrollHeight);
	var bw = Math.max(cw, sw);
	var bh = Math.max(ch, sh);

	//显示庶罩层
	var dm = $(mk);
	if(mk){
		if(!dm)dm = document.createElement("div");
		dm.id = mk;
		dm.className = 'dialog_mk';
		with(dm.style){width = bw+'px'; height = bh+'px'; if(dialog_isie){filter = " Alpha(Opacity=0)";}else{opacity = 0;}}
		document.body.appendChild(dm);
	}else{
		if(dm)document.body.removeChild(dm);
	}
	//显示对话框
	var dl = $(id);
	if(!dl)dl = document.createElement("div");
	dl.id = id;
	dl.className = 'dialog_dl';
	with(dl.style){if(w)width = w+'px'; if(h)height = h+'px'; zIndex = 999; left = 0; top = 0; if(dialog_isie){filter = " Alpha(Opacity=0)";}else{opacity = 0;}}
	document.body.appendChild(dl);
	dl.innerHTML = '';//清空内容	
	//写入内容
	var html = '<div class="dialog_box"><div class="dialog_bar" ondblclick="dialog_hide(\'' + id + '\',\'' + mk + '\',' + (100-cst) + ')" onmousedown="dialog_dragstart(event, \'' + id + '\')" onmouseup="dialog_dragstop(event);" onselectstart="return false;">\
				<span class="dialog_fl dialog_ico">' + ti + '&nbsp;</span><span class="dialog_fr dialog_control">\
				<img onclick="dialog_hide(\'' + id + '\',\'' + mk + '\',' + (100-cst) + ')" src="' + this.path + this.skin + '/dialog_close.gif" />\
				</span>\
				</div>';
	html += '<div class="dialog_main">';
	html += cc ? cc : '<div style="text-align:center;"><img src="' + this.path + this.skin + '/dialog_loading.gif" /></div>';
	
	if(ty == 1){
		html += '<div class="dialog_btn"><img onclick="dialog_hide(\'' + id + '\',\'' + mk + '\',' + (100-cst) + ')" src="' + this.path + this.skin + '/dialog_no.gif" /></div>';
	}
	if(ty == 2){
		html += '<div class="dialog_btn"><img onclick="dialog_hide(\'' + id + '\',\'' + mk + '\',' + (100-cst) + ',true)" src="' + this.path + this.skin + '/dialog_yes.gif" />\
				&nbsp;&nbsp;&nbsp;\
				<img onclick="dialog_hide(\'' + id + '\',\'' + mk + '\',' + (100-cst) + ',false)" src="' + this.path + this.skin + '/dialog_no.gif" /></div>';
	}
	
	html += '</div></div>';
	
	dl.innerHTML = html;
	
	if(ob){
		var obh = parseInt(ob.offsetHeight); 
		var obl = parseInt(ob.offsetLeft); 
		var obt = parseInt(ob.offsetTop); 
		
		var _ob = ob;
		do {
			_ob = _ob.offsetParent;
			obl	+= parseInt(_ob.offsetLeft);
			obt += parseInt(_ob.offsetTop);
		} while(_ob.tagName != 'BODY');
		
		//修正显示位置
		if((obl + parseInt(dl.offsetWidth)) > (cw + doc.scrollLeft)){
			obl = cw + doc.scrollLeft - parseInt(dl.offsetWidth);
		}
		if((obt + parseInt(dl.offsetHeight)) > (ch + doc.scrollTop)){
			//obt = ch + doc.scrollTop - parseInt(dl.offsetHeight) - 10;
			obt = obt - dl.offsetHeight - obh;
		}
		if(obl < 0)obl = 0;
		if(obt < 0)obt = 0;
		
		var dsl = obl;
		var dst = obt + obh;
	}else{
		var dw = parseInt(dl.offsetWidth);
		var dh = parseInt(dl.offsetHeight);
		var dsl = doc.scrollLeft + parseInt((cw-dw)/2);
		var dst = doc.scrollTop + parseInt((ch - dh)/2);
	}
	dl.style.left = dsl + 'px';
	dl.style.top = dst + 'px';
	
	if(!dialog_object[id])dialog_object[id] = {};
	if(ct > 0){
		try{clearTimeout(dialog_object[id]['sto']);}catch(e){}
		dialog_object[id]['sto'] = window.setTimeout(function(){dialog_hide(id, mk, 100-cst);}, ct);
	}
	try{clearTimeout(dialog_object[id]['cefo']);}catch(e){}
	elementevent(document, 'click', dialog_object[id]['cef'], false);
	dialog_show(id, mk, st, 100-cst);

	return dl;
}
dialog.prototype.exists = function(id){
	return $(id);
}
//id，ev:onyes、onno、onclose，function
dialog.prototype.event = function(id, ev, func){
	try{
		id = $(id).id;		
		dialog_object[id][ev] = func;
	}catch(e){}
}
//对话框id, mk:id/false显示庶罩层，cst:0-100渐变关闭，confirm
dialog.prototype.close = function(id, mk, cst, yn){
	if($(id))dialog_hide(id,mk,cst,yn);
}
//全局函数
dialog_show = function(id, mk, st, cst){
	if(st > 100)st = 100;
	try{if(dialog_isie) {$(id).style.filter = 'Alpha(Opacity='+st+')';} else {$(id).style.opacity = st/100;}}catch(e){}
	try{if(dialog_isie) {$(mk).style.filter = 'Alpha(Opacity='+(st/2)+')';} else {$(mk).style.opacity = st/200;}}catch(e){}
	if(st == 100){
		///*
		//点document关闭对话框
		try{clearTimeout(dialog_object[id]['cefo']);}catch(e){}
		dialog_object[id]['cefo'] = window.setTimeout(function(){
			dialog_object[id]['cef'] = dialog_docclick(null, id, mk, cst);
			elementevent(document, 'click', dialog_object[id]['cef'], true);
		}, 250);
		//*/
		return;	
	}
	window.setTimeout(function(){dialog_show(id,mk,st+25,cst);}, dialog_isie ? 1 : 50);
}
dialog_hide = function(id, mk, cst, yn){
	try{clearTimeout(dialog_object[id]['sto']);}catch(e){}//清除自动关闭计时
	if(cst <= 0){
		try{clearTimeout(dialog_object[id]['cefo']);}catch(e){}
		elementevent(document, 'click', dialog_object[id]['cef'], false);
		try{document.body.removeChild($(id));}catch(e){}
		try{document.body.removeChild($(mk));}catch(e){}

		try{if(yn === true)if(typeof dialog_object[id]['onyes'] == 'function')dialog_object[id]['onyes']();}catch(e){}
		try{if(yn === false)if(typeof dialog_object[id]['onno'] == 'function')dialog_object[id]['onno']();}catch(e){}
		try{if(typeof dialog_object[id]['onclose'] == 'function')dialog_object[id]['onclose']();}catch(e){}
		return;	
	}
	try{if(dialog_isie) {$(id).style.filter = 'Alpha(Opacity='+cst+')';} else {$(id).style.opacity = cst/100;}}catch(e){}
	try{if(dialog_isie) {$(mk).style.filter = 'Alpha(Opacity='+(cst/2)+')';} else {$(mk).style.opacity = cst/200;}}catch(e){}
	window.setTimeout(function(){dialog_hide(id,mk,cst-25,yn);}, dialog_isie ? 1 : 50);
}
function dialog_docclick(e, id, mk, cst) {
	return function(){
		if(dialog_isie){
			if(!e) e = window.event;
		}else{
			try{
				for(var i = 0; i < arguments.length; i ++){
					if(arguments[i].constructor.toString().indexOf('Event') != -1){
						e = arguments[i];
						break;
					}
				}
			}catch(ex){}
		}
		if((e.clientX > $(id).offsetLeft && e.clientX < $(id).offsetLeft + $(id).offsetWidth) && 
			(e.clientY > $(id).offsetTop && e.clientY < $(id).offsetTop + $(id).offsetHeight)){
			//
		}else{
			try{clearTimeout(dialog_object[id]['cefo']);}catch(e){}
			elementevent(document, 'click', dialog_object[id]['cef'], false);
			dialog_hide(id, mk, cst);
		}
	}
}
function dialog_dragstart(e, id) {
	dialog_dgdiv = $(id);
	//if(dialog_isie){dialog_dgdiv.style.filter = " Alpha(Opacity=50)";}else{dialog_dgdiv.style.opacity = 0.5;}
	//切换坐标
	dialog_dgdiv.style.zIndex = parseInt(dialog_dgdiv.style.zIndex) + 2;
	if(!e) e = window.event;
    dialog_dgX = e.clientX - parseInt(dialog_dgdiv.style.left);
    dialog_dgY = e.clientY - parseInt(dialog_dgdiv.style.top);
	elementevent(document, 'mousemove', dialog_dragmove, true);
	//document.onmousemove = dialog_dragmove;
}
function dialog_dragmove(e) { 
    if(!e) e = window.event;
    dialog_dgdiv.style.left = (e.clientX - dialog_dgX) + 'px';
    dialog_dgdiv.style.top = (e.clientY - dialog_dgY) + 'px';
}
function dialog_dragstop(e) {
	elementevent(document, 'mousemove', dialog_dragmove, false);
	//document.onmousemove = null;
	//if(dialog_isie){dialog_dgdiv.style.filter = " Alpha(Opacity=100)";}else{dialog_dgdiv.style.opacity = 1;}
	//还原坐标
	dialog_dgdiv.style.zIndex = parseInt(dialog_dgdiv.style.zIndex) - 2;
	dialog_dgX=dialog_dgY =0;
}