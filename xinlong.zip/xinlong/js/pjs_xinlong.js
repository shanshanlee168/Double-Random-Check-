
var ran=0;
var range1=0,range2=0;
var myNumber,myNumber2,realStartCheckPointer;
var completeBody;
var CheckCompanyNumbering=0,checkPersonNumbering=0;
var TotalCheckNumber=0,TotalPersonNumber=0;
var getingDataFlag=0;//正在抽检
var maxDelayNumber=0,maxDelayNumber2=0;//找不到合适的记录，抽检停止时间
var check_flag=0;
var get_check_type=1;
var check_person_name="";
var parameter1="",parameter2="";
/*将产生随机数的方法进行封装*/
function sjs1(range1) {
    ran=Math.random()*range1;//[0,range1)的随机数
    var result=parseInt(ran);//将数字转换成整数
    return result;
}
function sjs2(range2) {
    ran=Math.random()*range2;//[0,range2)的随机数
    var result=parseInt(ran);//将数字转换成整数
    return result;
}
/*对显示随机数的方法进行封装*/
function showRandomNum1() {
    var figure=sjs1(range1);
    $("#first").html(figure);
	if(getingDataFlag > 0)
	{
		getingDataFlag--;
		return;
	}
	getingDataFlag=10;
    insertOneLine(figure,CheckCompanyNumbering,2);
    if(CheckCompanyNumbering>=TotalCheckNumber || maxDelayNumber>5)
    {
        $("#start")[0].disabled=false;
        clearInterval(myNumber);
    }
    maxDelayNumber++;
        
}
function showRandomNum2() {
    var figure2=sjs2(range2);
    $("#second").html(figure2);
    
	if(getingDataFlag > 0)
	{
		getingDataFlag--;
		return;
	}
	getingDataFlag=10;
    insertOnePerson(figure2,checkPersonNumbering,2);
    if(checkPersonNumbering>=TotalPersonNumber || maxDelayNumber2>5)
    {
        $("#start2")[0].disabled=false;
        clearInterval(myNumber2);
    }    
    maxDelayNumber2++;
        
}

function insertOnePerson(num1,no,flag) {
	var url="";
	if(flag==1)url="searchCheckPerson.jsp?legal_number="+num1+"&serial="+no+"&para_flag="+flag;
	else if(flag==2)url="searchCheckPerson.jsp?"+parameter2+"&number1="+num1+"&serial="+no+"&para_flag="+flag;

	//alert(url);
	$.get(url,function(data,status){
		if(status=="success")
		{
			var name = data.getElementsByTagName("keyPerson")[0].firstChild.data;
			check_person_name += name+",";
	        var check_personBody = document.getElementById("check_person");
		    var cell, txtNode;  
	        cell = document.createElement("td");      

	        txtNode = document.createTextNode(name);  
	        cell.appendChild(txtNode);  
	        	        
	        check_personBody.appendChild(cell);
			checkPersonNumbering++;
			getingDataFlag=0;
			maxDelayNumber2=0;
			}
	  });
}

function insertOneLine(num1,no,flag) {
	var url="";
	if(flag==1)url="searchCheckCompany.jsp?enterprise_name="+num1+"&serial="+no+"&check_flag="+check_flag+"&para_flag="+flag;
	else if(flag==2)url="searchCheckCompany.jsp?"+parameter1+"&number1="+num1+"&serial="+no+"&check_flag="+check_flag+"&para_flag="+flag;

//	alert(url);
	$.get(url,function(data,status){
		if(status=="success")
		{
		    var row, cell, txtNode;  
	        row = document.createElement("tr");  
	        cell = document.createElement("th");      

	        txtNode = document.createTextNode(no);  
	        cell.appendChild(txtNode);  
	        row.appendChild(cell);
	        
	        var cell2, txtNode2;
	        cell2 = document.createElement("th");      
	        txtNode2 = document.createTextNode(data.getElementsByTagName("keyName")[0].firstChild.data);  
	        cell2.appendChild(txtNode2);  
	        row.appendChild(cell2);
	        
	        var cell3, txtNode3;
	        cell3 = document.createElement("th");      
	        txtNode3 = document.createTextNode(data.getElementsByTagName("keyAddress")[0].firstChild.data);  
	        cell3.appendChild(txtNode3);  
	        row.appendChild(cell3);
	        
	        var cell4, txtNode4;
	        cell4 = document.createElement("th");      
	        txtNode4 = document.createTextNode(data.getElementsByTagName("keyLeading")[0].firstChild.data);  
	        cell4.appendChild(txtNode4);
	        row.appendChild(cell4);
	        
	        var cell5, txtNode5;
	        cell5 = document.createElement("th");      
	        txtNode5 = document.createTextNode(data.getElementsByTagName("keyNumber")[0].firstChild.data);  
	        cell5.appendChild(txtNode5);  
	        row.appendChild(cell5);
	        
	        completeBody.appendChild(row);
			CheckCompanyNumbering++;
			getingDataFlag=0;
			maxDelayNumber=0;
			}
	  });
}

function check_title()
{
	var checkTask = document.getElementById("check_task");
	if (checkTask.value.length < 2) {//如果值为空，那么文本框获得焦点
		checkTask.focus();
		checkTask.style.background="#FF0000";
		return 0;
	}
	else{
		checkTask.style.background="#FFFFFF";	
	}
	var checkThings = document.getElementById("check_things");
	if (checkThings.value.length < 2) {//如果值为空，那么文本框获得焦点
		checkThings.focus();
		checkThings.style.background="#FF0000";
		return 0;
	}
	else{
		checkThings.style.background="#FFFFFF";	
	}
	return 1;
}

function start_check1()
{
	if(check_title() == 0)return;
	get_check_type = 1;
	
	var task = document.getElementById("check_task").value;
	var event = document.getElementById("check_things").value;
	var number = document.getElementById("check_number").value;
	
	var myDate = new Date();
	check_flag = myDate.getTime();
	
	var check_personBody = document.getElementById("check_person");
    var oldChild=check_personBody.lastChild;
    while(oldChild != null)
    {
    	check_personBody.removeChild(oldChild);
        oldChild=check_personBody.lastChild;
    }


    completeBody = document.getElementById("checkResult");
    oldChild=completeBody.lastChild;
    while(oldChild != null)
    {
    	var tmpString=oldChild.textContent;
    	if(tmpString.indexOf("序号")>1)break;
	
        completeBody.removeChild(oldChild);
        oldChild=completeBody.lastChild;
    }
    TotalCheckNumber = document.getElementById("check_number").value;
    OldCheckNumber = TotalCheckNumber;
    if(TotalCheckNumber<1)return;
	$("#start")[0].disabled=true;
	$.get("saveCheckTitle.jsp?task="+task+"&event="+event+"&number="+number+"&flag="+check_flag,function(data,status){
		if(status=="success")
		{
			}
	  });
	CheckCompanyNumbering=1;
	maxDelayNumber=0;
	var enterpriseName = document.getElementById("enterprise_name").value;//主体名称
	var industryCategory = document.getElementById("industry_category").value;//行业门类
	var industryCode = document.getElementById("industry_code").value;//行业代码
	var industryStatus = document.getElementById("industry_status").value;//企业状态
	var enterpriseType = document.getElementById("enterprise_type").value;//企业类型
	
	parameter1="industry_category="+industryCategory+"&industry_code="+industryCode
	+"&industry_status="+industryStatus+"&enterprise_type="+enterpriseType;

	if(enterpriseName.length > 4)
	{
		insertOneLine(enterpriseName,CheckCompanyNumbering,1);
		realStartCheckPointer=setInterval(RealStartCheck1,1000);
	}
	else
		RandStartCheck1();
}

function RealStartCheck1() {
	RandStartCheck1();
    clearInterval(realStartCheckPointer);
}

function RandStartCheck1() {
    range1=7071;
	getingDataFlag=0;
    myNumber=setInterval(showRandomNum1,200);//多长时间运行一次
}

function start_check2()
{
	if(check_title() == 0)return;
	get_check_type = 2;

	var check_personBody = document.getElementById("check_person");
    var oldChild=check_personBody.lastChild;
    while(oldChild != null)
    {
    	check_personBody.removeChild(oldChild);
        oldChild=check_personBody.lastChild;
    }
	TotalPersonNumber = document.getElementById("person_number").value;
	if(TotalPersonNumber<1)return;
	$("#start2")[0].disabled=true;
	
	var url="saveCheckTitle.jsp?task=100010002&event="+check_person_name+"&number=1&flag="+check_flag;
	$.get(url,function(data,status){
	  });
    /*将开始标签禁用，停止标签启用*/
	maxDelayNumber2=0;
	checkPersonNumbering=1;
	check_person_name="";
    
	var legalNumber = document.getElementById("legal_number").value;//执法证号
	var checkerJob = document.getElementById("checker_job").value;//职务
	var workPlace = document.getElementById("work_place").value;//工作单位
	var checkerCategory = document.getElementById("checker_category").value;//执法类别
	var checkerRange = document.getElementById("checker_range").value;//执法范围
	
	parameter2="checker_job="+checkerJob+"&work_place="+workPlace
	+"&checker_category="+checkerCategory+"&checker_range="+checkerRange;

	if(legalNumber.length > 4)
	{
		insertOnePerson(legalNumber,CheckCompanyNumbering,1);
		realStartCheckPointer=setInterval(RealStartCheck2,1000);
	}
	else
		RandStartCheck2();
	
}

function RealStartCheck2() {
	RandStartCheck2();
    clearInterval(realStartCheckPointer);
}

function RandStartCheck2() {
    range2=134;
	getingDataFlag=0;
    myNumber2=setInterval(showRandomNum2,200);//多长时间运行一次
}

function save_check()
{
	if(check_flag<1)return;
	var realCompanyNumber=CheckCompanyNumbering-1;
	var url="saveCheckTitle.jsp?task=100010001&event="+check_person_name+"&number="+realCompanyNumber+"&flag="+check_flag;
	$.get(url,function(data,status){
		if(status=="success")alert("保存成功!");
	  });
	
/*	var o=createXMLHttpRequest();       
    var url = "saveCheckTitle.jsp?task=100010001&event=1&number=1&flag=1";
    XMLHttpReq.open("GET", url, true);   
    XMLHttpReq.onreadystatechange = function()
	{
		if (XMLHttpReq.readyState == 4) { // 判断对象状态  
			if (XMLHttpReq.status == 200) { // 信息已经成功返回，开始处理信息   
				 window.alert("保存成功!");   
			}else { //页面不正常   
				window.alert("Something wrong happend!");   
				  }   
		}   
	};//指定响应函数   
    XMLHttpReq.send(null); // 发送请求  */
}
