/*
// @author : lael
// blog : http://hi.baidu.com/lael80
// http://www.gzyd.net
// all right reserved.
*/
//全局变量
var validator_object = {};
var validator = function(path){
	this.path = path ? path : 'javascript/validator/';
	this.error = '';
}
//f:表单id
//o:当前操作id
//w:是否使用返回错误，默认否(this.error)
/*
<input v="true/false" t="类型或正则表达式" q="要匹配的元素ID" d="yyyy-mm-dd hh:ii:ss" r="正确提示信息" e="错误提示信息" m="填写提示信息" o="显示信息元素id" min="25" max="255" />
*/
//
validator.prototype.check = function(f, o, w){
	if(!$(f))return false;
	var res = true;
	var els = this.getels($(f));
	this.error = '';
	for(var i = 0; i < els.length; i ++){
		var s = els[i];
		if($(o)){
			if($(o).id != s.id)continue;
		}
		var v = this.getatt(s, 'v');
		if(!v)continue;
		var t = this.getatt(s, 't');
		var c = true;
		if(v == 'true' || s.value != ''){
			switch(t){
				case '':
				case null:
				case false:
				case 'default':
				case 'string':
					c = /.+/.test(s.value);
					break;
				case 'safe':
					c = /^[a-zA-Z]+(\w)*$/.test(s.value);
					break;
				case 'username':
				case 'account':
					c = s.value.toLowerCase().match(new RegExp("/\\s+|^c:\\con\\con|[%,\*\"\\s\<\>\&]|\xA1\xA1|\xAC\xA3|^guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8/")) == null;
					break;
				case 'password':
					c = !/[\'\"\\]/.test(s.value);
					break;
				case 'email':
					c = /^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(s.value);
					break;
				case 'int':
					c = /^\d+$/.test(s.value);
					break;
				case 'real':
					c = /^(\-)?\d+(\.\d+)?$/.test(s.value);
					break;
				case 'phone':
					c = /^[0-9\(\)\-\s,\/（）、，]+$/.test(s.value);
					break;
				case 'idcard':
					c = this.strlen(s, 15, 18);
					if(c){
						c = /^[\d]{6}(19|20)*[\d]{2}((0[1-9])|(11|12))([012][\d]|(30|31))[\d]{1,4}$/.test(s.value.toLowerCase().replace('x', ''));
					}					
					break;
				case 'datetime':
					c = _dateutils.validator(s.value, this.getatt(s, 'd'));
					break;
				case 'group':
					var g = this.getels($(f), s);
					var n = this.getatt(s, 'min');
					var x = this.getatt(s, 'max');
					var l = 0;
					for(var j = 0; j < g.length; j ++){
						if(g[j].checked)l ++;
					}			
					if(v == 'true' || l > 0){
						if(!n)n = 1;
						if(l < n * 1)c = false;
						if(x)if(l > x * 1)c = false;
					}
					break;
				case 'equal':
				case 'equals':
					c = s.value == $(this.getatt(s, 'q')).value;
					break;
				default:
					c = (new RegExp(t)).test(s.value);
					break;
			}
			if(c){
				if(t != 'group'){
					c = this.strlen(s);
				}
			}
		}
		if(!c)res = false;
		this.show(s, (v == 'false' && s.value == '') ? 'm' : (c ? 'r' : 'e'), w);
	}
	if(!$(o))return res;
}
validator.prototype.init = function(f){
	if(!$(f))return;
	
	validator_object[$(f).id] = this;
	var els = this.getels($(f));
	for(var i = 0; i < els.length; i ++){
		var s = els[i];
		var v = this.getatt(s, 'v');
		if(!v)continue;
		s.onblur = function(e){
			validator_object[this.form.id].check(this.form, this);
		}
		s.onfocus = function(e){
			validator_object[this.form.id].reset(this.form, this);
		}
	}
	this.reset(f);
}
validator.prototype.reset = function(f, o){
	if(!$(f))return false;
	var els = this.getels($(f));
	for(var i = 0; i < els.length; i ++){
		var s = els[i];
		if($(o)){
			if($(o).id != s.id)continue;
		}
		var v = this.getatt(s, 'v');
		if(!v)continue;
		this.show(s, 'm');
	}
}
validator.prototype.show = function(s, c, w){
	this.clsres(s);
	var h = this.getatt(s, c);
	if(w && h && c == 'e'){
		this.error += '<li>' + h + '</li>';
	}else{
		if(c != 'm' && !h){
			c = 'm';
			h = this.getatt(s, c);
		}
		if(h){
			var o = $(this.getatt(s, 'o'));
			if(!o)o = document.createElement("DIV");
			if(!o.id){
				o.id = 'validator';
				o.style.border = '0';
				o.style.padding = '2px 2px 0 20px';
				o.style.background = 'url(' + this.path + c + '.gif) no-repeat left center';
				o.style.textAlign = 'left';	
				o.style.color = c == 'e' ? '#ff0000' : '#999999';
				s.parentNode.appendChild(o);
			}
			o.style.display = '';
			o.innerHTML = h;
		}
	}
}
validator.prototype.geterr = function(){
	return this.error == '' ? false : '<p>以下原因导致提交失败：</p><ol>' + this.error + '</ol>';
}
validator.prototype.clsres = function(s){
	var o = $(this.getatt(s, 'o'));
	if(o)o.style.display = 'none';
	for(var i = 0; i < s.parentNode.childNodes.length; i ++){
		if(s.parentNode.childNodes[i].id == 'validator'){
			s.parentNode.removeChild(s.parentNode.childNodes[i]);
		}
	}
}
validator.prototype.getels = function(f, o){
	var l = o ? this.objlen(f.elements[o.id]) : this.objlen(f.elements);
	if(l){
		var e = new Array;
		for(var i = 0; i < l; i ++){
			e.push(o ? f.elements[o.id][i] : f.elements[i]);
		}
		return e;
	}
	return o ? new Array(f.elements[o.id]) : false;	
}
validator.prototype.getatt = function(o, k){
	try{
		var r = o.getAttribute(k);
		if(r)return r;
	}catch(e){}
	return false;
}
validator.prototype.strlen = function(s, n, x){
	if(!n)n = this.getatt(s, 'min');
	if(!x)x = this.getatt(s, 'max');
	var l = s.value.replace(/[^\x00-\xff]/g, "***").length;
	if(n)if(l < n * 1)return false;
	if(x)if(l > x * 1)return false;
	return true;
}
validator.prototype.objlen = function(o){
	try{
		var r = o.length;
		if(r)return r;
	}catch(e){}
	return false;
}