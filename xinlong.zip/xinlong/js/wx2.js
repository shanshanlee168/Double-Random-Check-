﻿function show(val){
    alert(val);
}
