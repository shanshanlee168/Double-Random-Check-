package com.stdexpress.web;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.commons.lang3.StringUtils;

import com.stdexpress.sdk.Config;

public class InitServlet extends HttpServlet {

    private static final long serialVersionUID = 7813015310531038437L;

    public void init(ServletConfig config) throws ServletException {
        String systemConfigureFile = config.getInitParameter("systemConfigureFile");
        if (StringUtils.isBlank(systemConfigureFile)) {
            systemConfigureFile = "weixin.properties";
        }
        new Config(systemConfigureFile).init();
    }
}
