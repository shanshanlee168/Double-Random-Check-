package com.stdexpress.wechat.oauth;

import java.io.IOException;
import java.net.URLEncoder;
import java.text.MessageFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.stdexpress.sdk.Config;

public class OAuthRequestServlet extends HttpServlet {

    private static final long serialVersionUID = -8726410560446266794L;

    private static final Logger LOGGER = LoggerFactory.getLogger(OAuthRequestServlet.class);

    private final String OAUTH_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?appid={0}&redirect_uri={1}&response_type=code&scope=snsapi_base&state=1#wechat_redirect";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 鏈嫤鎴墠璁块棶鐨勫湴鍧�
        String to = request.getParameter("to");
        // 鍒板井淇¤繘琛屾巿鏉冨悗鐨勫洖璋冨湴鍧�
        String toUrl = Config.getWebDomain() + Config.getWebOAuthResponseUrl();

        if (StringUtils.isNotBlank(to)) {
            toUrl += "?to=" + to;
        }
//        LOGGER.debug("toUrl={}", toUrl);

        String encoderUrl = URLEncoder.encode(toUrl, "UTF-8");

        String redirectUrl = MessageFormat.format(OAUTH_URL, Config.getAppId(), encoderUrl);
//        LOGGER.debug("redirectUrl={}", redirectUrl);

        response.sendRedirect(redirectUrl);
    }

}
