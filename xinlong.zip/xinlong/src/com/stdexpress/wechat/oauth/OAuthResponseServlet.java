package com.stdexpress.wechat.oauth;

import java.io.IOException;
import java.text.MessageFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.stdexpress.sdk.Config;
import com.stdexpress.sdk.model.User;
import com.stdexpress.sdk.util.UserUtils;
import com.stdexpress.sdk.util.http.HttpUtils;
import com.stdexpress.wechat.WeixinException;

public class OAuthResponseServlet extends HttpServlet {

    private static final long serialVersionUID = -8726410560446266794L;

    private static final Logger LOGGER = LoggerFactory.getLogger(OAuthResponseServlet.class);

    protected final String OAUTH_ACCESS_TOKEN = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={0}&secret={1}&code={2}&grant_type=authorization_code";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String code = request.getParameter("code");
        String to = request.getParameter("to");

        LOGGER.debug("code={}", code);
//        LOGGER.debug("to={}", to);

        String result = HttpUtils.sendGET(MessageFormat.format(OAUTH_ACCESS_TOKEN, Config.getAppId(), Config.getSecret(), code));
//        LOGGER.debug("result:{}", result);

        JSONObject obj = JSON.parseObject(result);
        int errcode = obj.getIntValue("errcode");
        if (errcode > 0) {
            LOGGER.error("errcode={}", errcode);
            throw new RuntimeException(result);
        }
        String openId = obj.getString("openid");

        try {
            User user = UserUtils.getUserInfo(openId);
            LOGGER.debug("nickname:{}, city:{}", user.getNickName(), user.getCity());

            request.getSession().setAttribute("USER", user);

            response.sendRedirect(to);
        } catch (WeixinException e) {
            LOGGER.error(e.getMessage(), e);
            throw new RuntimeException();
        }
    }
}
