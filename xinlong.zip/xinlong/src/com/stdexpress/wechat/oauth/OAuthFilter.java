package com.stdexpress.wechat.oauth;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;

import com.stdexpress.sdk.Config;

public class OAuthFilter implements Filter {

    public void init(FilterConfig fConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        HttpSession session = httpRequest.getSession();

        if (!isAllowed(httpRequest)) {
            Object user = session.getAttribute("USER");
            if (null == user) {
                httpResponse.sendRedirect(redirectTo(httpRequest, Config.getWebOAuthReqeustUrl()));
                return;
            }
        }

        chain.doFilter(request, response);
    }

    private boolean isAllowed(HttpServletRequest request) {
        String url = request.getRequestURL().toString();
        return url.contains("login") || url.contains("logout");
    }

    protected String redirectTo(HttpServletRequest request, String redirect) {
        String url = request.getRequestURL().toString();
        String ctx = request.getContextPath();
        if (!redirect.startsWith("/")) {
            redirect = "/" + redirect;
        }
        if (request.getMethod().equalsIgnoreCase("get")) {
            String redirct_url = "";
            try {
                if (StringUtils.isNotBlank(request.getQueryString())) {
                    url += "?" + request.getQueryString();
                }
                redirct_url = URLEncoder.encode(url, "UTF-8");
                if (redirect.indexOf("?") > -1) {
                    if (redirct_url.indexOf("&") > -1) {
                        redirect += "&to=" + redirct_url;
                    } else {
                        redirect += "to=" + redirct_url;
                    }
                } else {
                    redirect += "?to=" + redirct_url;
                }
            } catch (UnsupportedEncodingException e) {
                // do nothing
            }
        }
        return url.subSequence(0, url.indexOf(ctx)) + ctx + redirect;
    }
}
