package com.stdexpress.wechat;

public class WeixinException extends Exception {

    private static final long serialVersionUID = -2972908947741842813L;

    public WeixinException(String msg) {
        super(msg);
    }
}
