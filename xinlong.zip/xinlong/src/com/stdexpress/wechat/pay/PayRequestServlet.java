﻿package com.stdexpress.wechat.pay;

import java.io.IOException;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.stdexpress.sdk.Config;
import com.stdexpress.sdk.model.User;
import com.stdexpress.sdk.util.WXPayUtils;
import com.stdexpress.sdk.util.XMLUtils;
import com.stdexpress.sdk.util.http.HttpUtils;
import com.stdexpress.wechat.BaseServlet;
import com.stdexpress.wechat.pay.vo.Pay4WechatVo;
import com.stdexpress.wechat.pay.vo.PayResponse;

public class PayRequestServlet extends BaseServlet {

    private static final long serialVersionUID = 6911687830976272685L;

    private static final Logger LOGGER = LoggerFactory.getLogger(PayRequestServlet.class);

    private static final String URL_PAY_UNIFIEDORDER = "/pay/unifiedorder";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("USER");
        
        PayResponse payResponse = new PayResponse();

        // 获取IP
        String ip = HttpUtils.getIpAddr(request);
        // 获取从页面提交过来的数据，包括订单号，订单描述，订单金额
        String outTradeNo = request.getParameter("orderNo");
        // 中文有乱码的可能，自行处理下
        String body = "快递运费ОПЛАТА ДОСТАВКИ";//request.getParameter("body");
        // 微信的单位是分，必须为整数
        int amount = Integer.valueOf(request.getParameter("amount")).intValue();

        createWeixinPayResponse(payResponse, ip, body, amount, user.getOpenId(), outTradeNo);

        // 返回json
        rendJson(response, payResponse);
    }

    private void createWeixinPayResponse(PayResponse payResponse, String ip, String body, int amount, String openId, String outTradeNo) {
        SortedMap<String, Object> parameterMap = new TreeMap<>();
        parameterMap.put("appid", Config.getAppId());
        parameterMap.put("mch_id", Config.getMchId());
        parameterMap.put("device_info", "WEB");
        parameterMap.put("nonce_str", WXPayUtils.createNoncestr());
        parameterMap.put("body", body);
        parameterMap.put("out_trade_no", outTradeNo);
        parameterMap.put("total_fee", amount);
        parameterMap.put("spbill_create_ip", ip);
        parameterMap.put("notify_url", Config.getWebDomain() + Config.getWebPayNoticeUrl());
        parameterMap.put("trade_type", "JSAPI");
        parameterMap.put("openid", openId);
        String sign = WXPayUtils.createSign(parameterMap);
        parameterMap.put("sign", sign);

        LOGGER.debug("unified order parameters: {}", parameterMap);
        String xml = XMLUtils.getRequestXml(parameterMap);
        LOGGER.debug("unified order xml: {}", xml);
        String result = HttpUtils.sendWxPayPOST(URL_PAY_UNIFIEDORDER, xml);
        LOGGER.debug("unified order result: {}", result);

        // 解析微信返回的信息，以Map形式存储便于取值
        Map<String, Object> map = XMLUtils.doXMLParse(result);
        if (String.valueOf(map.get("return_code")).equals("FAIL")) {
            payResponse.setIsSuccess(false);
            payResponse.setMessage(String.valueOf(map.get("return_msg")));
            return;
        }

        // 获取预支付ID
        String prepayId = String.valueOf(map.get("prepay_id"));

        SortedMap<String, Object> params = new TreeMap<>();
        params.put("appId", Config.getAppId());
        params.put("timeStamp", String.valueOf(System.currentTimeMillis() / 1000));
        params.put("nonceStr", WXPayUtils.createNoncestr());
        params.put("package", "prepay_id=" + prepayId);
        params.put("signType", "MD5");
        // paySign的生成规则和Sign的生成规则一致
        params.put("paySign", WXPayUtils.createSign(params));

        LOGGER.debug("pay parameters:{}", params);

        Pay4WechatVo wechatVo = new Pay4WechatVo().fromMap(params);
        payResponse.setWechatorder(JSONObject.toJSONString(wechatVo));

        LOGGER.debug("pay json: {}", payResponse.getWechatorder());
    }
}
