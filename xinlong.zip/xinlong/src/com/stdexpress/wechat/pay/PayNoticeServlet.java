﻿package com.stdexpress.wechat.pay;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.SortedMap;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.stdexpress.sdk.util.WXPayUtils;
import com.stdexpress.sdk.util.XMLUtils;
import com.stdexpress.wechat.BaseServlet;

/*
 * 微信支付后的通知地址，不能加权限，必须开放权限，不然收不到回调数据
 */
public class PayNoticeServlet extends BaseServlet {

    private static final long serialVersionUID = 3083864925272712556L;

    private static final Logger LOGGER = LoggerFactory.getLogger(PayNoticeServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOGGER.debug("-------------付款成功----------------");
        try (InputStream inStream = request.getInputStream();
                ByteArrayOutputStream outSteam = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[1024];
            int len = 0;
            while ((len = inStream.read(buffer)) != -1) {
                outSteam.write(buffer, 0, len);
            }

            // 获取微信调用我们notify_url的返回信息
            String result = new String(outSteam.toByteArray(), "UTF-8");
            Map<String, Object> resultMap = XMLUtils.doXMLParse(result);
            if (LOGGER.isDebugEnabled()) {
                for (Map.Entry<String, Object> p : resultMap.entrySet()) {
                    LOGGER.debug("key={}, value={}", p.getKey(), p.getValue());
                }
            }
            if ("SUCCESS".equalsIgnoreCase(String.valueOf(resultMap.get("result_code")))) {
                // 先验证签名
                // 将返回的map进行排序
                SortedMap<String, Object> sortedResultMap = WXPayUtils.sortMap(resultMap);
                String paySign = WXPayUtils.createSign(sortedResultMap);
                if (paySign.equals(resultMap.get("sign"))) {
                    // 取到订单号, 更新状态
                    String orderNo = String.valueOf(resultMap.get("out_trade_no"));
                    // 此处换成自己的业务逻辑
                    LOGGER.debug("wechat return orderNo=" + orderNo);
                    
                    // 告诉微信服务器，我收到信息了，不要在调用回调action了
                    response.getWriter().write(XMLUtils.setXML("SUCCESS", ""));
                } else {
                    // 签名错误，告诉微信失败了
                    response.getWriter().write(XMLUtils.setXML("FAIL", ""));
                }
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

}
