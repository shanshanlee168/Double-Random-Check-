﻿package com.stdexpress.wechat.pay.vo;

import com.alibaba.fastjson.annotation.JSONField;

public class PayResponse {

    @JSONField(name = "success")
    private Boolean isSuccess = Boolean.TRUE;

    private String  message;

    private String  payType;

    private String  wechatorder;

    public Boolean getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(Boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPayType() {
        return payType;
    }

    public void setPayType(String payType) {
        this.payType = payType;
    }

    public String getWechatorder() {
        return wechatorder;
    }

    public void setWechatorder(String wechatorder) {
        this.wechatorder = wechatorder;
    }

}
