﻿package com.stdexpress.wechat.pay.vo;

import java.util.Map;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.annotation.JSONType;

@JSONType(orders = { "appId", "timeStamp", "nonceStr", "package", "signType", "paySign" })
public class Pay4WechatVo {
    private String appId;

    private String timeStamp;

    private String nonceStr;

    @JSONField(name = "package")
    private String packageStr;

    private String signType;

    private String paySign;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getNonceStr() {
        return nonceStr;
    }

    public void setNonceStr(String nonceStr) {
        this.nonceStr = nonceStr;
    }

    public String getPackageStr() {
        return packageStr;
    }

    public void setPackageStr(String packageStr) {
        this.packageStr = packageStr;
    }

    public String getSignType() {
        return signType;
    }

    public void setSignType(String signType) {
        this.signType = signType;
    }

    public String getPaySign() {
        return paySign;
    }

    public void setPaySign(String paySign) {
        this.paySign = paySign;
    }

    public Pay4WechatVo fromMap(Map<String, Object> map) {
        appId = String.valueOf(map.get("appId"));
        timeStamp = String.valueOf(map.get("timeStamp"));
        nonceStr = String.valueOf(map.get("nonceStr"));
        packageStr = String.valueOf(map.get("package"));
        signType = String.valueOf(map.get("signType"));
        paySign = String.valueOf(map.get("paySign"));

        return this;
    }
}
