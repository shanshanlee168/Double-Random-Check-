﻿package com.stdexpress.wechat.pay;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class PayMockServlet extends HttpServlet {

    private static final long serialVersionUID = -6403900743397782200L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 姝ゅ鎹㈡垚鑷繁鐨勪笟鍔￠�杈�
        // 鎴戝湪杩欏厛妯℃嫙绯荤粺鍚庡彴鐢熸垚涓�釜璁㈠崟鍙凤紝鐒跺悗甯﹀埌椤甸潰
        String orderNo = String.valueOf(System.currentTimeMillis());
        request.setAttribute("ORDER_NO", orderNo);
        request.getRequestDispatcher("pay.jsp").forward(request, response);
    }
}
