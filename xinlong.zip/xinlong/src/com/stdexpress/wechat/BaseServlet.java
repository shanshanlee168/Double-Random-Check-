package com.stdexpress.wechat;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public class BaseServlet extends HttpServlet {

    private static final long serialVersionUID = 1121698302633144671L;

    private static final Logger LOG = LoggerFactory.getLogger(BaseServlet.class);

    protected void rendJson(HttpServletResponse resp, Object obj) {
        resp.setHeader("Content-type", "text/html;charset=UTF-8");
        PrintWriter out = null;
        try {
            out = resp.getWriter();

            String json = JSONObject.toJSONString(obj);
            LOG.debug("json: {}", json);
            out.print(JSONObject.toJSONString(obj));
            out.flush();
        } catch (IOException e) {
            LOG.error(e.getMessage(), e);
        } finally {
            if (null != out) {
                out.close();
            }
        }
    }

}
