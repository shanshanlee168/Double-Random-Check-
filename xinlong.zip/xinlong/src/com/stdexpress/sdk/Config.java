package com.stdexpress.sdk;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Config {

    private static final Logger LOG = LoggerFactory.getLogger(Config.class);

    private static Properties prop;
    private String fileName;

    public Config(String fileName) {
        this.fileName = fileName;
    }

    // 赋权类型
    public static final String GRANT_TYPE = "client_credential";

    // 开发者设置的token
    private static String token;

    // 微信服务器域名(无需登录)
    private static String mpDomain;

    // 微信API服务器域名
    private static String apiDomain;

    // 支付服务器域名
    private static String payDomain;

    // 开发者申请的appId
    private static String appId;

    // 开发者申请的secret密钥
    private static String secret;

    // 开发者申请的支付secret密钥
    private static String paySecret;

    // 支付证书
    private static String payCert;

    // 开发者申请的支付商户ID
    private static String mchId;

    /**
     * 从数据库资源文件中读数据库配置信息
     */
    public void init() {
        try (InputStream is = Config.class.getClassLoader().getResourceAsStream(fileName)) {
            // read configure file
            prop = new Properties();
            prop.load(is);
            mpDomain = prop.getProperty("wx.mp.domain");
            apiDomain = prop.getProperty("wx.api.domain");
            payDomain = prop.getProperty("wx.pay.domain");
            token = prop.getProperty("wx.token");
            appId = prop.getProperty("wx.appId");
            secret = prop.getProperty("wx.secret");
            mchId = prop.getProperty("wx.pay.mchId");
            paySecret = prop.getProperty("wx.pay.secret");
            payCert = prop.getProperty("wx.pay.cert");
        } catch (IOException e) {
            LOG.error("read {} file exception", fileName, e);
        }
    }

    public static String getMpDomain() {
        return mpDomain;
    }

    public static String getApiDomain() {
        return apiDomain;
    }

    public static String getPayDomain() {
        return payDomain;
    }

    public static String getToken() {
        return token;
    }

    public static String getAppId() {
        return appId;
    }

    public static String getSecret() {
        return secret;
    }

    public static String getPaySecret() {
        return paySecret;
    }

    public static String getMchId() {
        return mchId;
    }

    public static String getPayCert() {
        return payCert;
    }

    public static String get(final String key) {
        return prop.getProperty(key);
    }

    public static String getWebDomain() {
        return get("web.domain");
    }
    
    public static String getWebOAuthReqeustUrl() {
        return get("web.oauth.request.url");
    }
    
    public static String getWebOAuthResponseUrl() {
        return get("web.oauth.response.url");
    }

    public static String getWebPayNoticeUrl() {
        return get("web.pay.notice.url");
    }

}
