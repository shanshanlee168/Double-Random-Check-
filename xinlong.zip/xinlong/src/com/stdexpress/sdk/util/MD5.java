package com.stdexpress.sdk.util;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class MD5 {

    private static final Logger LOG = LoggerFactory.getLogger(MD5.class);

    public final static String hex(byte[] array) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < array.length; ++i) {
            sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).substring(1, 3));
        }
        return sb.toString();
    }

    public final static String code(String message) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return hex(md.digest(message.getBytes("UTF-8")));
        } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
            LOG.error(e.getMessage(), e);
        }
        return null;
    }

    /**
     * 32bit once encryption of MD5
     */
    public final static String once(String s) {
        return encryption(s, 1);
    }

    /**
     * 32bit twice encryption of MD5
     */
    public final static String twice(String s) {
        return encryption(s, 2);
    }

    /**
     * number times 32bit encryption of MD5
     */
    public final static String encryption(String s, int num) {
        for (int i = 0; i < num; i++) {
            s = MD5.code(s);
        }
        return s;
    }
    
  //���ܴ���  
    private final static Pattern pattern = Pattern.compile("\\d+");
    public static String decode(String src,String key) {  
        if(src == null || src.length() == 0){  
            return src;  
        }  
        //�������ʽ�ַ���ƥ��  
        Matcher m = pattern.matcher(src);  
          
        List<Integer> list = new ArrayList<Integer>();  
        //find����(����ƥ��):����ȥ�������봮���Ƿ�ƥ����Ӧ���Ӵ�  
        while (m.find()) {  
            try {  
                //����ƥ�䵽�����ַ���  
                String group = m.group();  
                list.add(Integer.valueOf(group));  
            } catch (Exception e) {  
                e.printStackTrace();  
                return src;  
            }  
        }  
          
        //�����ƥ����ַ���  
        if (list.size() > 0) {  
            try {  
                byte[] data = new byte[list.size()];  
                byte[] keys = key.getBytes();  
                //����ڼ��ܹ��̵Ľ��ܹ���  
                for (int i = 0; i < data.length; i++) {  
                    data[i] = (byte) (list.get(i) - (0xff & keys[i % keys.length]));  
                }  
                return new String(data, "utf-8");  
            } catch (UnsupportedEncodingException e){  
                e.printStackTrace();  
            }  
            return src;  
        } else {  
            return src;  
        }  
      }
}