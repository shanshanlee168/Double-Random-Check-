package com.stdexpress.sdk.util.http;

public enum MediaType {
    IMAGE, VOICE, VIDEO, THUMB
}
