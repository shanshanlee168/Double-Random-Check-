package com.stdexpress.sdk.util.http;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.stdexpress.sdk.Config;

public final class HttpUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtils.class);

    private static final String UTF_8  = "UTF-8";

    private HttpUtils() {
    }

    public static String sendPOST(String url, String data) {
        return doSendHttp(createHttpPost(url, data));
    }

    public static String sendWxPOST(String url, String data) {
        return sendPOST(Config.getApiDomain() + url, data);
    }

    public static String sendGET(String url) {
        return doSendHttp(new HttpGet(url));
    }

    public static String sendWxGET(String url) {
        return sendGET(Config.getApiDomain() + url);
    }

    public static String sendWxPayPOST(String url, String data) {
        return sendPOST(Config.getPayDomain() + url, data);
    }

    public static String sendWxCertPOST(String url, String data) {
        return doSendCertHttp(createHttpPost(Config.getPayDomain() + url, data), Config.getPayCert(), Config.getMchId());
    }

    private static HttpPost createHttpPost(String url, String data) {
        HttpPost httpPost = new HttpPost(url);
        StringEntity params = new StringEntity(data, UTF_8);
        httpPost.setEntity(params);

        return httpPost;
    }

    private static String doSendHttp(HttpUriRequest request) {
        try (CloseableHttpClient client = isHttp(request) ? SSLHttpClient.createSSLClientDefault() : HttpClients
                .createDefault(); CloseableHttpResponse httpResponse = client.execute(request)) {
            return EntityUtils.toString(httpResponse.getEntity(), UTF_8);
        } catch (UnsupportedEncodingException | ClientProtocolException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }

    private static String doSendCertHttp(HttpPost httpPost, String certFile, String certPass) {
        try (CloseableHttpClient client = getCertHttpClient(certFile, certPass);
                CloseableHttpResponse httpResponse = client.execute(httpPost)) {
            return EntityUtils.toString(httpResponse.getEntity(), UTF_8);
        } catch (UnsupportedEncodingException | ClientProtocolException | KeyManagementException
                | UnrecoverableKeyException | KeyStoreException | NoSuchAlgorithmException | CertificateException e) {
            LOGGER.error(e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }

    private static CloseableHttpClient getCertHttpClient(String certFile, String certPass) throws KeyStoreException,
            NoSuchAlgorithmException, CertificateException, IOException, KeyManagementException,
            UnrecoverableKeyException {
        KeyStore keyStore = KeyStore.getInstance("PKCS12");

        try (FileInputStream instream = new FileInputStream(new File(certFile))) {
            keyStore.load(instream, certPass.toCharArray());
        }

        // Trust own CA and all self-signed certs
        SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, certPass.toCharArray()).build();
        // Allow TLSv1 protocol only
        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" }, null,
                SSLConnectionSocketFactory.getDefaultHostnameVerifier());
        return HttpClients.custom().setSSLSocketFactory(sslsf).build();
    }

    private static boolean isHttp(HttpUriRequest request) {
        return isHttp(request.getURI().toString());
    }

    private static boolean isHttp(String url) {
        if (StringUtils.isNotBlank(url)) {
            return url.toLowerCase().contains("https://");
        }
        return true;
    }
    
    public static String getIpAddr(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        } else {
            // 濡傛灉閫氳繃浜嗗绾у弽鍚戜唬鐞嗙殑璇濓紝X-Forwarded-For鐨勫�骞朵笉姝竴涓紝鑰屾槸涓�覆IP鍊�
            String[] ips = StringUtils.split(ip, ",");
            if (ips != null && ips.length > 1) {
                for (String p : ips) {
                    if ("unknown".equalsIgnoreCase(p)) {
                        ip = p;
                        break;
                    }
                }
            }
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        if (ip != null) {
            String[] ips = StringUtils.split(ip, ",");
            return ips[0];
        }
        return ip;
    }
}
