package com.stdexpress.sdk.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.SortedMap;
import java.util.TreeMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.stdexpress.sdk.Config;

public final class WXPayUtils {

    private static Logger LOGGER = LoggerFactory.getLogger(WXPayUtils.class);

    public static String createNoncestr(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    public static String createNoncestr() {
        return createNoncestr(6);
    }

    public static String createSign(SortedMap<String, Object> parameters) {
        StringBuffer sb = new StringBuffer();
        for (Map.Entry<String, Object> map : parameters.entrySet()) {
            String k = map.getKey();
            Object v = map.getValue();
            if (null != v && !"".equals(v.toString()) && !"sign".equals(k) && !"key".equals(k)) {
                sb.append(k + "=" + v + "&");
            }
        }
        sb.append("key=" + Config.getPaySecret());
        LOGGER.debug("before sign:{}", sb.toString());

        String sign = MD5.code(sb.toString()).toUpperCase();
        LOGGER.debug("after sign:{}", sign);

        return sign;
    }

    public static SortedMap<String, Object> sortMap(Map<String, Object> parameters) {
        List<String> keys = new ArrayList<>(parameters.keySet());
        Collections.sort(keys);

        SortedMap<String, Object> map = new TreeMap<>();
        for (String key : keys) {
            map.put(key, parameters.get(key));
        }

        return map;
    }

}
