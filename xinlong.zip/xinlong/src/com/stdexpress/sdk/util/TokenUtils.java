﻿package com.stdexpress.sdk.util;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.stdexpress.sdk.Config;
import com.stdexpress.sdk.util.http.HttpUtils;
import com.stdexpress.wechat.WeixinException;

public final class TokenUtils {

    private final static Logger LOGGER          = LoggerFactory.getLogger(TokenUtils.class);

    // 获取tokenURL
    public final static String  URL_ACCESSTOKEN = "/token";

    // 获取access_token的时间
    private static long         getTime;

    // 当前获取的access_token(不用每次获取)
    private static String       access_token;

    private TokenUtils() {
    }

    /**
     * 获取access_token
     * 
     * @return
     * @throws WeixinException
     */
    public static String getAccessToken(int ResetFlag) throws WeixinException {
        if (null != access_token && ResetFlag==0) {// 已经获取了access_token
            long currentTime = System.currentTimeMillis();
            if ((currentTime - getTime) < 7200000) {// 过期了 | access_token有效期为7200秒
                return access_token;
            }
        }

        // 从服务端从新获取access_token
        String url = URL_ACCESSTOKEN + "?grant_type=" + Config.GRANT_TYPE + "&appid=" + Config.getAppId()
                + "&secret=" + Config.getSecret();

        String json = HttpUtils.sendWxGET(url);
        getTime = System.currentTimeMillis();
        JSONObject obj = JSON.parseObject(json);
        access_token = obj.getString("access_token");
        if (StringUtils.isBlank(access_token)) {// 错误
            LOGGER.error("access token cloud not get", json);
            throw new WeixinException(json);
        }
        LOGGER.debug("access_token:{}", access_token);
        return access_token;
    }

}
