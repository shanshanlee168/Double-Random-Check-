﻿package com.stdexpress.sdk.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.stdexpress.sdk.model.User;
import com.stdexpress.sdk.util.http.HttpUtils;
import com.stdexpress.wechat.WeixinException;

public final class UserUtils {

    private final static Logger LOGGER = LoggerFactory.getLogger(UserUtils.class);

    // 获取tokenURL
    public final static String URL_USER_INFO = "/user/info";

    // 获取关注用户列表
    public final static String URL_USER_GET = "/user/get";

    private UserUtils() {
    }

    public static User getUserInfo(final String openId) throws WeixinException {
        String url = URL_USER_INFO + "?access_token=" + TokenUtils.getAccessToken(0) + "&openid=" + openId + "&lang=zh_CN";

        String json = HttpUtils.sendWxGET(url);
        if (StringUtils.isBlank(json)) {// 错误
            LOGGER.error("cloud not get user info");
            throw new WeixinException(json);
        }
        return JSON.parseObject(json, User.class);
    }

    public static List<String> getUserIds() throws WeixinException {
        return getUserIds(null);
    }

    private static List<String> getUserIds(final String openId) throws WeixinException {
        String url = URL_USER_GET + "?access_token=" + TokenUtils.getAccessToken(0);
        if (StringUtils.isNotBlank(openId)) {
            url += "&next_openid=" + openId;
        }

        List<String> userIds = new ArrayList<String>();
        String json = HttpUtils.sendWxGET(url);
        if (StringUtils.isBlank(json)) {// 错误
            LOGGER.error("cloud not get user id list");
            throw new WeixinException(json);
        }
        JSONObject obj = JSON.parseObject(json);
        String nextOpenId = obj.getString("next_openid");
        int count = obj.getIntValue("count");
        if (count > 0 && StringUtils.isNotBlank(nextOpenId)) {
            String userIdsJson = obj.getJSONObject("data").getJSONArray("openid").toJSONString();
            userIds = JSON.parseArray(userIdsJson, String.class);
            userIds.addAll(getUserIds(nextOpenId));
        }

        return userIds;
    }

}
