package com.stdexpress.sdk.model;

import com.alibaba.fastjson.annotation.JSONField;

public class User {

    private String subscribe;

    @JSONField(name = "openid")
    private String openId;

    @JSONField(name = "nickname")
    private String nickName;
    private String sex;
    private String language;
    private String city;
    private String province;
    private String country;

    @JSONField(name = "headimgurl")
    private String headImgUrl;

    @JSONField(name = "subscribe_time")
    private String subscribeTime;

    @JSONField(name = "unionid")
    private String unionId;

    private String remark;

    @JSONField(name = "groupid")
    private String groupId;

    public String getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(String subscribe) {
        this.subscribe = subscribe;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getSubscribeTime() {
        return subscribeTime;
    }

    public void setSubscribeTime(String subscribeTime) {
        this.subscribeTime = subscribeTime;
    }

    public String getUnionId() {
        return unionId;
    }

    public void setUnionId(String unionId) {
        this.unionId = unionId;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    @Override
    public String toString() {
        return "User [subscribe=" + subscribe + ", openId=" + openId + ", nickName=" + nickName + ", sex=" + sex
                + ", language=" + language + ", city=" + city + ", province=" + province + ", country=" + country
                + ", headImgUrl=" + headImgUrl + ", subscribeTime=" + subscribeTime + ", unionId=" + unionId
                + ", remark=" + remark + ", groupId=" + groupId + "]";
    }

}
