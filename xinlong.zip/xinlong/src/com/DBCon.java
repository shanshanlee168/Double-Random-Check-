﻿package com;
import java.sql.*;

/**
 * <p>数据库访问类</p>
 */
  public class DBCon {
  Connection con = null;
  Statement stmt = null;
  PreparedStatement ps = null;
  ResultSet rs = null;
  String sql = null;
  
  public DBCon() {
  }

  //使用JDBC连接数据库
  public void getConnection() {
    try {
      Class.forName("com.mysql.jdbc.Driver");   //加载MYSQL JDBC驱动程序
      String url= "jdbc:mysql://127.0.0.1:3306/youliandb?useUnicode=true&characterEncoding=GBK";
      String username="root";//用户名
      String password="g858_root$123";//用户密码
      con = DriverManager.getConnection(url, username, password); //连接数据库
      //System.err.println("连接数据库服务器成功！");
    }
    catch (Exception e) {
      System.out.println("连接数据库服务器失败！");
      e.printStackTrace();
    }
  }

  //查询数据
  public ResultSet selectRecord(String sql) {
    try {
      stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
      rs = stmt.executeQuery(sql);

    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return rs;
  }

  //增加数据
  public int insertRecord(String sql) {
    int num = 0;
    try {
      stmt = con.createStatement();
      stmt.executeUpdate(sql);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return num;
  }

  //修改数据
  public int updateRecord(String sql) {
    int num = 0;
    try {
      stmt = con.createStatement();
      stmt.executeUpdate(sql);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return num;
  }

  //删除数据
  public int deleteRecord(String sql) {
    int num = 0;
    try {
      stmt = con.createStatement();
      stmt.executeUpdate(sql);
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    return num;
  }
  
  //关闭数据库连接并释放资源
  public void closeConn() {
    try {
      if (rs != null) {
        rs.close();
        rs = null;
      }
      if (stmt != null) {
        stmt.close();
        stmt = null;
      }
      if (con != null) {
        con.close();
        con = null;
      }
    }
    catch (Exception e) {
      e.printStackTrace();
    }
    finally {
      con = null;
    }
  }
}
  