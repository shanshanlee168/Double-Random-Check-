package com;

import java.io.IOException;
import java.util.*;
import java.io.OutputStream;

import com.DBCon;
import java.sql.ResultSet;
import java.sql.SQLException;

import jxl.Workbook;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

public class SimpleExcelWrite {
  public void createExcel(OutputStream os) throws WriteException,IOException{
    //创建工作薄
    WritableWorkbook workbook = Workbook.createWorkbook(os);
    //创建新的一页
    WritableSheet sheet = workbook.createSheet("First Sheet",0);
    //创建要显示的内容,创建一个单元格，第一个参数为列坐标，第二个参数为行坐标，第三个参数为内容

    /*DBCon dbCommCon = new DBCon();
	dbCommCon.getConnection();
	String downexcel="";
	downexcel= "select * from user_general";
	System.out.println(downexcel);*/
    try{
    DBCon dbconn = new DBCon();
    dbconn.getConnection();//调用DBCon数据库连接方法
    System.out.println("数据库已连接！");
    String sql="select * from upexcel where flg_bsck='9'";
    ResultSet rs=dbconn.selectRecord(sql);	
    //List list=new ArrayList();
     List<String> list1=new ArrayList<String>();   
	 List<String> list2=new ArrayList<String>(); 
	 List<String> list3=new ArrayList<String>(); 
	 List<String> list4=new ArrayList<String>();  
	 List<String> list5=new ArrayList<String>(); 
	 List<String> list6=new ArrayList<String>(); 
	 List<String> list7=new ArrayList<String>();
	 List<String> list8=new ArrayList<String>(); 
	 List<String> list9=new ArrayList<String>(); 
	 List<String> list10=new ArrayList<String>();
	 List<String> list11=new ArrayList<String>(); 
	 List<String> list12=new ArrayList<String>(); 
	 List<String> list13=new ArrayList<String>();
	 List<String> list14=new ArrayList<String>(); 
	 List<String> list15=new ArrayList<String>(); 
	 List<String> list16=new ArrayList<String>();
	 List<String> list17=new ArrayList<String>(); 
	 List<String> list18=new ArrayList<String>(); 
	 List<String> list19=new ArrayList<String>();
	 List<String> list20=new ArrayList<String>(); 
	 List<String> list21=new ArrayList<String>(); 
	 List<String> list22=new ArrayList<String>();
	 List<String> list23=new ArrayList<String>(); 
	 List<String> list24=new ArrayList<String>(); 
	 List<String> list25=new ArrayList<String>();
	 List<String> list26=new ArrayList<String>(); 
    while(rs.next()){
    	 list1.add(rs.getString("record_num"));
		 list2.add(rs.getString("usernum"));
		 list3.add(rs.getString("selfnum"));
		 list4.add(rs.getString("yj_code"));
		 list5.add(rs.getString("jdjname"));
		 list6.add(rs.getString("sj_name"));
		 list7.add(rs.getString("sj_countryname"));
		 list8.add(rs.getString("sj_statename"));
		 list9.add(rs.getString("sj_cityname"));
		 list10.add(rs.getString("sj_address"));
		 list11.add(rs.getString("sj_tel"));
		 list12.add(rs.getString("yj_weight"));
		 list13.add(rs.getString("jdjcode"));
		 list14.add(rs.getString("nj_enname"));
		 list15.add(rs.getString("nj_name"));
		 list16.add(rs.getString("sj_weight"));
		 list17.add(rs.getString("price"));
		 list18.add(rs.getString("nj_num"));
		 list19.add(rs.getString("nj_type"));
		 list20.add(rs.getString("jj_name"));
		 list21.add(rs.getString("jj_tel"));
		 list22.add(rs.getString("jj_address"));
		 list23.add(rs.getString("jj_province"));
		 list24.add(rs.getString("jj_cityname"));
		 list25.add(rs.getString("remark"));
		 list26.add(rs.getString("ru_yunfei"));
	 }
	if(list1 != null && list1.size()>0){//如果list中存入了数据，转化为数组  
		 String[] arr1=new String[list1.size()];//创建一个和list长度一样的数组  
		 String[] arr2=new String[list2.size()];
		 String[] arr3=new String[list3.size()];
		 String[] arr4=new String[list4.size()];
		 String[] arr5=new String[list5.size()];
		 String[] arr6=new String[list6.size()];
		 String[] arr7=new String[list7.size()];
		 String[] arr8=new String[list8.size()];
		 String[] arr9=new String[list9.size()];
		 String[] arr10=new String[list10.size()];
		 String[] arr11=new String[list11.size()];
		 String[] arr12=new String[list12.size()];
		 String[] arr13=new String[list13.size()];
		 String[] arr14=new String[list14.size()];
		 String[] arr15=new String[list15.size()];
		 String[] arr16=new String[list16.size()];
		 String[] arr17=new String[list17.size()];
		 String[] arr18=new String[list18.size()];
		 String[] arr19=new String[list19.size()];
		 String[] arr20=new String[list20.size()];
		 String[] arr21=new String[list21.size()];
		 String[] arr22=new String[list22.size()];
		 String[] arr23=new String[list23.size()];
		 String[] arr24=new String[list24.size()];
		 String[] arr25=new String[list25.size()];
		 String[] arr26=new String[list26.size()];
    for(int i=0;i<list1.size();i++){  
    	arr1[i]=list1.get(i);//数组赋值了
		arr2[i]=list2.get(i);
		arr3[i]=list3.get(i);
		arr4[i]=list4.get(i);
		arr5[i]=list5.get(i);
		arr6[i]=list6.get(i);
		arr7[i]=list7.get(i);
		arr8[i]=list8.get(i);
		arr9[i]=list9.get(i);
		arr10[i]=list10.get(i);
		arr11[i]=list11.get(i);
		arr12[i]=list12.get(i);
		arr13[i]=list13.get(i);
		arr14[i]=list14.get(i);
		arr15[i]=list15.get(i);
		arr16[i]=list16.get(i);
		arr17[i]=list17.get(i);
		arr18[i]=list18.get(i);
		arr19[i]=list19.get(i);
		arr20[i]=list20.get(i);
		arr21[i]=list21.get(i);
		arr22[i]=list22.get(i);
		arr23[i]=list23.get(i);
		arr24[i]=list24.get(i);
		arr25[i]=list25.get(i);
		arr26[i]=list26.get(i);
    }  
    //输出数组  
    for(int i=0;i<arr1.length;i++){  
	    System.out.println(arr1[i]);  
	 }
    
    Label labe1 = new Label(0, 0, "记录序号");
	sheet.addCell(labe1);
	Label labe2 = new Label(1, 0, "大宗用户编号");
	sheet.addCell(labe2);
	Label labe3 = new Label(2, 0, "用户自编号");
	sheet.addCell(labe3);
	Label labe4 = new Label(3, 0, "寄达局邮编");
	sheet.addCell(labe4);
	Label labe5 = new Label(4, 0, "寄达局名称");
	sheet.addCell(labe5);
	Label labe6 = new Label(5, 0, "收件人姓名（填写英文）");
	sheet.addCell(labe6);
	Label labe7 = new Label(6, 0, "英文国家名");
	sheet.addCell(labe7);
	Label labe8 = new Label(7, 0, "英文州名");
	sheet.addCell(labe8);
	Label labe9 = new Label(8, 0, "英文城市名");
	sheet.addCell(labe9);
	Label labe10 = new Label(9, 0, "收件人地址（填写英文）");
	sheet.addCell(labe10);
	Label labe11 = new Label(10, 0, "收件人电话");
	sheet.addCell(labe11);
	Label labe12 = new Label(11, 0, "邮件重量");
	sheet.addCell(labe12);
	Label labe13 = new Label(12, 0, "邮件号码");
	sheet.addCell(labe13);
	Label labe14 = new Label(13, 0, "内件名称");
	sheet.addCell(labe14);
	Label labe15 = new Label(14, 0, "内件英文名称");
	sheet.addCell(labe15);
	Label labe16 = new Label(15, 0, "单件重量");
	sheet.addCell(labe16);
	Label label7 = new Label(16, 0, "单价");
	sheet.addCell(label7);
	Label labe18 = new Label(17, 0, "内件数量");
	sheet.addCell(labe18);
	Label labe19 = new Label(18, 0, "内件类型代码（主要包括：1：礼品；2：文件；3、商品货样；4、退回物品；5、其他 ）");
	sheet.addCell(labe19);
	Label labe20 = new Label(19, 0, "寄件人名称（英文）");
	sheet.addCell(labe20);
	Label labe2l = new Label(20, 0, "寄件人联系电话");
	sheet.addCell(labe2l);
	Label labe22 = new Label(21, 0, "寄件人地址");
	sheet.addCell(labe22);
	Label labe23 = new Label(22, 0, "寄件人省名（英文）");
	sheet.addCell(labe23);
	Label labe24 = new Label(23, 0, "寄件人城市名（英文）");
	sheet.addCell(labe24);
	Label labe25 = new Label(24, 0, "邮件备注");
	sheet.addCell(labe25);
	Label labe26 = new Label(25, 0, "运费");
	sheet.addCell(labe26);
    
	for(int i=0;i<arr1.length;i++){ 
		Label labelC = new Label(0, i+1, arr1[i]);
		sheet.addCell(labelC);
		Label labe2C = new Label(1, i+1, arr2[i]);
		sheet.addCell(labe2C);
		Label labe3C = new Label(2, i+1, arr3[i]);
		sheet.addCell(labe3C);
		Label labe4C = new Label(3, i+1, arr4[i]);
		sheet.addCell(labe4C);
		Label labe5C = new Label(4, i+1, arr5[i]);
		sheet.addCell(labe5C);
		Label labe6C = new Label(5, i+1, arr6[i]);
		sheet.addCell(labe6C);
		Label labe7C = new Label(6, i+1, arr7[i]);
		sheet.addCell(labe7C);
		Label labe8C = new Label(7, i+1, arr8[i]);
		sheet.addCell(labe8C);
		Label labe9C = new Label(8, i+1, arr9[i]);
		sheet.addCell(labe9C);
		Label labe10C = new Label(9, i+1, arr10[i]);
		sheet.addCell(labe10C);
		Label labe11C = new Label(10, i+1, arr11[i]);
		sheet.addCell(labe11C);
		Label labe12C = new Label(11, i+1, arr12[i]);
		sheet.addCell(labe12C);
		Label label3C = new Label(12, i+1, arr13[i]);
		sheet.addCell(label3C);
		Label labe14C = new Label(13, i+1, arr14[i]);
		sheet.addCell(labe14C);
		Label labe15C = new Label(14, i+1, arr15[i]);
		sheet.addCell(labe15C);
		Label labe16C = new Label(15, i+1, arr16[i]);
		sheet.addCell(labe16C);
		Label label7C = new Label(16, i+1, arr17[i]);
		sheet.addCell(label7C);
		Label labe18C = new Label(17, i+1, arr18[i]);
		sheet.addCell(labe18C);
		Label labe19C = new Label(18, i+1, arr19[i]);
		sheet.addCell(labe19C);
		Label labe20C = new Label(19, i+1, arr20[i]);
		sheet.addCell(labe20C);
		Label labe2lC = new Label(20, i+1, arr21[i]);
		sheet.addCell(labe2lC);
		Label labe22C = new Label(21, i+1, arr22[i]);
		sheet.addCell(labe22C);
		Label labe23C = new Label(22, i+1, arr23[i]);
		sheet.addCell(labe23C);
		Label labe24C = new Label(23, i+1, arr24[i]);
		sheet.addCell(labe24C);
		Label labe25C = new Label(24, i+1, arr25[i]);
		sheet.addCell(labe25C);
		Label labe26C = new Label(25, i+1, arr26[i]);
		sheet.addCell(labe26C);
	}
	}
	
    dbconn.closeConn();						    
  }catch(Exception ex){
		System.err.println("Exception:"+ex.getMessage());
		ex.printStackTrace();
	   }
	
   /* Label labe1 = new Label(0, 0, "记录序号");
    sheet.addCell(labe1);
	Label labe2 = new Label(1, 0, "大宗用户编号");
	sheet.addCell(labe2);
	Label labe3 = new Label(2, 0, "用户自编号");
	sheet.addCell(labe3);
	Label labe4 = new Label(3, 0, "寄达局邮编");
	sheet.addCell(labe4);
	Label labe5 = new Label(4, 0, "寄达局名称");
	sheet.addCell(labe5);
    
	 
	Label labelC = new Label(0, 1, "aa");
	sheet.addCell(labelC);
	Label labe2C = new Label(1, 1, "aa");
	sheet.addCell(labe2C);
	Label labe3C = new Label(2, 1, "aa");
	sheet.addCell(labe3C);
	Label labe4C = new Label(3, 1, "aa");
	sheet.addCell(labe4C);
	Label labe5C = new Label(4, 1, "aa");
	sheet.addCell(labe5C);*/
	
    //把创建的内容写入到输出流中，并关闭输出流
    workbook.write();
    workbook.close();
    os.close();
  
  }
  
}
