﻿package com;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HttpsURLConnection;

import org.apache.catalina.util.Base64;
import org.apache.http.Consts;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.NodeList;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;

import util.MD5;

import com.stdexpress.sdk.util.XMLUtils;
import com.stdexpress.sdk.util.http.HttpUtils;

/**
 * <p>
 * 快递100
 * </p>
 */
public class KD100Con {

	private final static Logger LOGGER = LoggerFactory
			.getLogger(KD100Con.class);

	private static final String UTF8 = "utf-8";

	private static final String token = "AIzaSyBhSKznWjQlzP5Uz4QMemR7J7NFyxlBXHA";

	public String translate(String q, String from, String to) throws Exception {

		// String urlStr =
		// "https://www.googleapis.com/language/translate/v2?q="+q+"&target=zh&key=AIzaSyBhSKznWjQlzP5Uz4QMemR7J7NFyxlBXHA";

		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		nvps.add(new BasicNameValuePair("q", q));
		nvps.add(new BasicNameValuePair("target", to));
		nvps.add(new BasicNameValuePair("key", token));
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nvps,
				Consts.UTF_8);
		String urlStr = "https://www.googleapis.com/language/translate/v2?"
				+ EntityUtils.toString(entity);
		URL url = new URL(urlStr);

		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		InputStream stream;
		if (conn.getResponseCode() == 200) // success
		{
			stream = conn.getInputStream();
		} else {
			stream = conn.getErrorStream();
			return "";
		}

		BufferedReader reader = new BufferedReader(
				new InputStreamReader(stream));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
		/*System.out.println("result:" + result);
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(df.format(new Date()));*/

		JSONObject resultJson = JSON.parseObject(result.toString());

		JSONObject dataObj = JSON.parseObject(resultJson.getString("data"));
		JSONArray transObj = (JSONArray) dataObj.get("translations");
		JSONObject dst = (JSONObject) transObj.get(0);
		String text = dst.getString("translatedText");
		text = URLDecoder.decode(text, UTF8);
		// System.out.println("success:" + text);

		return text;
	}

	public String convertFinance(String finace,String from, String to) throws Exception {
		
/*		String firstStr = "";
		try {
			firstStr = HttpUtils
					.sendGET( "http://op.juhe.cn/onebox/exchange/currency?key=4855114ecadc17f90a454c7838deca8c&from="
							+ from+"&to="+to);
			System.out.println(firstStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "error";
		}
//		return firstStr;

		String text="";
		JSONObject jsonObject = JSON.parseObject(firstStr);

		JSONArray jsonArray = jsonObject.getJSONArray("result");
		if(jsonArray == null)return "error";
		Iterator<Object> it = jsonArray.iterator();
		if (it.hasNext()) {
			JSONObject jsonObject2 = (JSONObject) it.next();

			text = jsonObject2.getString("exchange");
		}
		return text;*/
		// String urlStr =
		// https://www.google.com/finance/converter?a=1&from=USD&to=CNY

		String urlStr = "https://finance.google.com/finance/converter?a="+finace+"&from="
				+ from+"&to="+to+"&meta=ei%3D6IzAWfHOH8-Z0AS20YjAAg";
		URL url = new URL(urlStr);

		HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
		InputStream stream;
		if (conn.getResponseCode() == 200) // success
		{
			stream = conn.getInputStream();
		} else {
			stream = conn.getErrorStream();
			return "error";
		}

		BufferedReader reader = new BufferedReader(
				new InputStreamReader(stream));
		StringBuilder result = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			result.append(line);
		}
//		return result.toString();

		String text="";
		int resultIndex1 = result.indexOf(from+" = ");
		if(resultIndex1>0)
		{
			int resultIndex2 = result.lastIndexOf(to+"</span>");
			line = result.substring(resultIndex1, resultIndex2);
			text = line.replace(from+" = <span class=bld>", "");
		}
		return text;
	}

	public void sendSmsToRussia(String dst_number,String parameterstr) throws UnsupportedEncodingException {
		String parameter=URLEncoder.encode(parameterstr, "UTF-8");
		//return parameter;
		String firstStr = "";
		try {			
			firstStr = HttpUtils
					.sendGET("https://smsc.ru/sys/send.php?login=std-express&charset=utf-8&psw=1234512345&phones="+
    	dst_number+"&mes="+parameter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try (InputStream in = new ByteArrayInputStream(firstStr.getBytes("UTF-8"))) {

        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
		
		LOGGER.debug("SmsToRussia:{}", dst_number+firstStr);
	}

	public String getNewOrder(String parameterstr,String address,String name,String phone,String goodsName) throws UnsupportedEncodingException {
		
		String parameter=parameterstr+
		"&dst_address="+URLEncoder.encode(address, "UTF-8")+"&dst_name="+URLEncoder.encode(name, "UTF-8")+
		"&dst_number="+URLEncoder.encode(phone, "UTF-8")+"&goods_name="+URLEncoder.encode(goodsName, "UTF-8");
		//return parameter;
		String firstStr = "";
		try {			
			firstStr = HttpUtils
					.sendGET("http://www.std-express.com:8989/rc_getNewOrder.php?"+parameter);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Error:1"+parameterstr+e;
		}
		//String firstStr = sendPost("http://www.std-express.com:8989/rc_getNewOrder.php?"+parameter,"");

		//firstStr=firstStr.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
		String backStr = "";
        try (InputStream in = new ByteArrayInputStream(firstStr.getBytes("UTF-8"))) {

            SAXBuilder builder = new SAXBuilder();
            Document doc = builder.build(in);
            Element root = doc.getRootElement();
			Element Order= root.getChild("Order");//StatusReport
			if(Order==null)return firstStr;
			backStr=Order.getAttributeValue("DispatchNumber");
			if(backStr==null)return firstStr;
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            return "Error:"+firstStr+parameterstr;
        }

        return backStr;/**/
	}

	public String getTrackingOrder(String orderNo,String orderDate) {

//		LOGGER.debug("getTrackingOrder:{}", orderNo+","+orderDate);
		String firstStr = "";
		try {
			firstStr = HttpUtils
					.sendGET("http://www.std-express.com:8989/rc_getTraking.php?orderName="
							+ orderNo+"&orderDate="+orderDate);
			System.out.println(firstStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "查不到此单号";
		}
		LOGGER.debug("backTrackingOrder:{}", firstStr);
		String backStr = "";
        try (InputStream in = new ByteArrayInputStream(firstStr.getBytes("UTF-8"))) {

            SAXBuilder builder = new SAXBuilder();
            Document doc = builder.build(in);
            Element root = doc.getRootElement();
			Element Order= root.getChild("Order");//StatusReport
			if(Order == null)return "cdek 查不到此单号!";
			Element Status=Order.getChild("Status");//Status
            //String Status_Report=root.getName();//StatusReport
            //String order_Report=Order.getName();//Status
            List booklist=Status.getChildren("State");//State
            int delete_state=0;
            for (Iterator iter = booklist.iterator(); iter.hasNext();) {
            	Element order = (Element) iter.next();
            	delete_state++;
            	if(delete_state==1)continue;
            	String Description=order.getAttributeValue("Description")+" "+
            			order.getAttributeValue("CityName");
            	String Date=order.getAttributeValue("Date");
            	String Date1=Date.substring(0,Date.indexOf('T'));
    			backStr = "</p>\n</div>\n</div>\n"+backStr;
    			backStr = Date1+backStr;
    			backStr = "<p>"+backStr;
    			backStr = "</p>\n"+backStr;
    			backStr = Description+backStr;
    			backStr = "<div class=\"weui-cell\">\n<div class=\"weui-cell__bd\">\n<p>"+backStr;
    			String Code=order.getAttributeValue("Code");
    			if(Code.equalsIgnoreCase("18"))
    			{
    				Element Call=Order.getChild("Call");
    				if(Call != null)
    				{
    					Element CallFail=Call.getChild("CallFail");
    					if(CallFail != null)
    					{
    						Element Fail=CallFail.getChild("Fail");
    		            	Description=Fail.getAttributeValue("ReasonDescription");
    		            	Date=Fail.getAttributeValue("Date");
    		            	Date1=Date.substring(0,Date.indexOf('T'));
    		    			backStr = "</p>\n</div>\n</div>\n"+backStr;
    		    			backStr = Date1+backStr;
    		    			backStr = "<p>"+backStr;
    		    			backStr = "</p>\n"+backStr;
    		    			backStr = Description+backStr;
    		    			backStr = "<div class=\"weui-cell\">\n<div class=\"weui-cell__bd\">\n<p>"+backStr;
    					}
    				}
    			}
            }
			String RecipientName = Order.getAttributeValue("RecipientName");
			if(RecipientName.length() > 1)
			{
				String Date=Order.getAttributeValue("DeliveryDate");
            	String Date1=Date.substring(0,Date.indexOf('T'));

    			backStr = "</p>\n</div>\n</div>\n"+backStr;
    			backStr = Date1+backStr;
    			backStr = "<p>"+backStr;
    			backStr = "</p>\n"+backStr;
    			backStr = "Отправление доставлено. Расписался:"+RecipientName+backStr;
    			backStr = "<div class=\"weui-cell\">\n<div class=\"weui-cell__bd\">\n<p>"+backStr;
			}
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return backStr;

	}

	public String getRussiaOder(String orderNumber) {
		String cnPath = getOderPath(orderNumber);
		String ruPath = "";
		// cnPath=new String(cnPath.getBytes("ISO-8859-1"), "UTF-8");
		try {
			ruPath = translate(cnPath, "zh", "ru");
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.debug("ru_order:{}", orderNumber);

		return ruPath;
	}

	// 使用JDBC连接数据库
	public String getOderPath(String orderNumber) {

		String firstStr = "";
		try {
			firstStr = HttpUtils
					.sendGET("http://www.kuaidi100.com/autonumber/auto?num="
							+ orderNumber + "&key=HMdvhMIV1365");
			System.out.println(firstStr);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "查不到此单号";
		}
		if (firstStr.length() < 10)
			return "<p class=\"weui-msg__desc\">查不到此单号!</p>";

		firstStr = firstStr.replace("[{", "{");
		firstStr = firstStr.replace("}]", "}");
		int moreIndex = firstStr.indexOf(",{");
		if (moreIndex > 0) {
			// secondStr=firstStr.substring(moreIndex+1, firstStr.length());
			firstStr = firstStr.substring(0, moreIndex);
		}

		JSONObject obj = JSON.parseObject(firstStr);
		String companyName = obj.getString("comCode");

		String backStr = "";
		backStr = getOneOder(companyName, orderNumber);
		LOGGER.debug("companyName:{},orderNumber:{}", companyName, orderNumber);

		return backStr;
	}

	public String getOneOder(String companyName, String orderNumber) {

		String param = "{\"com\":\"" + companyName + "\",\"num\":\""
				+ orderNumber + "\"}";
		String customer = "10185711F046E36E7B8F5D54CF5C7656";
		String key = "HMdvhMIV1365";
		String sign = MD5.encode(param + key + customer);
		HashMap<String, String> params = new HashMap<String, String>();
		params.put("param", param);
		params.put("sign", sign);
		params.put("customer", customer);

		// String
		// inParam="customer=10185711F046E36E7B8F5D54CF5C7656&param={\"com\":\"yuantong\",\"num\":\"885209981217498025\",\"from\":\"\",\"to\":\"\"}&sign=E280C6789E4107E631F5A4E601766B1A";
		// return inParam;/*
		String resp = "";
		try {
			resp = sendPost("http://poll.kuaidi100.com/poll/query.do", params);
			System.out.println(resp);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "查不到此单号";
		}
		// return resp;/*

		JSONObject jsonObject = JSON.parseObject(resp);
		Boolean result = jsonObject.getBoolean("result");
		if (result != null && result == false) {
			String bakMessage = "<p class=\"weui-msg__desc\">"
					+ jsonObject.getString("message") + "</p>\n";
			return bakMessage;
		}
		// 返回json的数组
		JSONArray jsonArray = jsonObject.getJSONArray("data");
		String backStr = "";
		Iterator<Object> it = jsonArray.iterator();
		while (it.hasNext()) {
			JSONObject jsonObject2 = (JSONObject) it.next();

			backStr += "<div class=\"weui-cell\">\n<div class=\"weui-cell__bd\">\n<p>";
			backStr += jsonObject2.getString("context");
			backStr += "</p>\n";
			backStr += "<p>";
			backStr += jsonObject2.getString("ftime");
			backStr += "</p>\n</div>\n</div>\n";
		}
		return backStr;/**/
	}

	/**
	 * 向指定URL发送POST请求
	 * 
	 * @param url
	 * @param paramMap
	 * @return 响应结果
	 */
	public static String sendPost(String url, HashMap<String, String> paramMap) {
		PrintWriter out = null;
		BufferedReader in = null;
		String result = "";
		try {
			URL realUrl = new URL(url);
			// 打开和URL之间的连接
			URLConnection conn = realUrl.openConnection();
			// 设置通用的请求属性
			conn.setRequestProperty("accept", "*/*");
			conn.setRequestProperty("connection", "Keep-Alive");
			conn.setRequestProperty("user-agent",
					"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
			// conn.setRequestProperty("Charset", "UTF-8");
			// 发送POST请求必须设置如下两行
			conn.setDoOutput(true);
			conn.setDoInput(true);
			// 获取URLConnection对象对应的输出流
			out = new PrintWriter(conn.getOutputStream());

			// 设置请求属性
			String param = "";
			if (paramMap != null && paramMap.size() > 0) {
				Iterator<String> ite = paramMap.keySet().iterator();
				while (ite.hasNext()) {
					String key = ite.next();// key
					String value = paramMap.get(key);
					param += key + "=" + value + "&";
				}
				param = param.substring(0, param.length() - 1);
			}

			// 发送请求参数
			out.print(param);
			// flush输出流的缓冲
			out.flush();
			// 定义BufferedReader输入流来读取URL的响应
			in = new BufferedReader(
					new InputStreamReader(conn.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				result += line;
			}
		} catch (Exception e) {
			System.err.println("发送 POST 请求出现异常！" + e);
			e.printStackTrace();
		}
		// 使用finally块来关闭输出流、输入流
		finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return result;
	}

	private static String Stream2String(InputStream in, String encoding) {

		if (in == null) {

			return null;
		}
		StringBuffer out = new StringBuffer();
		try {

			char[] b = new char[1024];
			InputStreamReader inread = new InputStreamReader(in, encoding);

			for (int n; (n = inread.read(b)) != -1;) {
				String line = new String(b, 0, n);
				out.append(line);
			}

		} catch (Exception e) {

			e.printStackTrace();
		}

		return out.toString();
	}

	public static String sendPost(String url, String param) {
		
		 /*String returnStr = ""; 
		 HttpURLConnection httpConn = null; 
		 InputStream fis = null;
		 
		 try {
		 
		 URL httpurl = new URL(url); httpConn = (HttpURLConnection)
		 httpurl.openConnection();
		 
		 httpConn.setDoOutput(true); 
		 httpConn.setRequestMethod("POST");
		 httpConn.setRequestProperty("Content-Type", "text/xml"); //
		 httpConn.setConnectTimeout(600000); 
		 httpConn.setReadTimeout(600000);
		 
		 OutputStream op = httpConn.getOutputStream();
		 op.write(param.getBytes());
		 
		 
		 op.flush(); 
		 op.close();
		 
		 if(httpConn.getResponseCode() == 200)
		 { 
			 fis = httpConn.getInputStream(); 
			 returnStr = Stream2String(fis,"utf-8"); 
			 }
		 System.out.println(returnStr);
		 
		 } 
		 catch (Exception e) 
		 { System.out.println(e.getMessage()); } 
		 finally
		 { 
			 try { if(fis!=null){ fis.close(); } } 
			 catch (IOException e) 
			 {
			 e.printStackTrace(); } 
			 httpConn.disconnect(); 
		 }
		 return returnStr;/**/
		
		 OutputStreamWriter out = null; BufferedReader in = null; 
		 String	 result = ""; 
		 try { 
			 URL realUrl = new URL(url); // 打开和URL之间的连接
			 URLConnection conn = realUrl.openConnection(); // 设置通用的请求属性
			 conn.setDoOutput(true); conn.setDoInput(true);
			 conn.setRequestProperty("Pragma", "no-cache");
			 conn.setRequestProperty("Cache-Control", "no-cache");
			 conn.setRequestProperty("Content-Type", "text/xml"); //
			 conn.setRequestProperty("content-type", "application/x-www-form-urlencoded"); // 发送POST请求必须设置如下两行 
			 out = new OutputStreamWriter(conn .getOutputStream()); // 发送请求参数 
			 out.write(new String(param.getBytes("ISO-8859-1"))); // flush输出流的缓冲 
			 out.flush();
			 out.close(); // 定义BufferedReader输入流来读取URL的响应 
			 in = new BufferedReader(new InputStreamReader(conn .getInputStream())); 
			 String	 line; 
			 while ((line = in.readLine()) != null) 
			 { result += line; } 
		 	}
			catch (Exception e) 
		 	{
				System.out.println("发送 POST 请求出现异常！"+e);
				result="发送 POST 请求出现异常！"+e; e.printStackTrace(); 
			 }
			 //使用finally块来关闭输出流、输入流 
		 finally{ 
			 try{ if(out!=null){ out.close(); }
			 if(in!=null){ in.close(); } 
			 } catch(IOException ex){
		 ex.printStackTrace(); 
		 } 
		} 
		return result;/**/
	}
}
