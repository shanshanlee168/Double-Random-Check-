package Upload;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import exceltool.TestJXL;

//http://commons.apache.org/fileupload/using.html

public class SimpleUploadFile extends HttpServlet {
	/**
	 * 文件上传到的目录
	 */
	File uploadDirectoryFile;
	/**
	 * 临时文件目录
	 */
	File tempDirectoryFile;

	private long requestSizeRequestSize=1024*3000;
	private int maxMemorySize=1024*10;
	
	public void init() throws ServletException {
		String nativeWebAppFoldPath=this.getServletContext().getRealPath("/");
		String tempDirectory=this.getInitParameter("TempDirectory");
		tempDirectoryFile=new File(nativeWebAppFoldPath+tempDirectory);
		String uploadDirectory=this.getInitParameter("UploadDirectory");
		uploadDirectoryFile=new File(nativeWebAppFoldPath+uploadDirectory);		
		//文件夹不存在就自动创建
		if(!tempDirectoryFile.exists())tempDirectoryFile.mkdirs();
		if(!uploadDirectoryFile.exists())uploadDirectoryFile.mkdirs();
		try {
			requestSizeRequestSize=Long.parseLong(this.getInitParameter("RequestSizeRequestSize"));
			maxMemorySize = Integer.parseInt(this.getInitParameter("MaxMemorySize"));
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
	}


	public void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String bag = (String)request.getSession().getAttribute("bag"); 
		System.out.println("bag");
		System.out.println(bag);
		System.out.println("bag");
		File uploadedFile = processFileUpload(request);
		//以便setattrubit可以设置和读取
		//request.getRequestDispatcher("Commons_FileUpload/resultFile.jsp").forward(request,response);
		//response.sendRedirect("newInfo.jsp");
		response.setContentType("text/html; charset=UTF-8");
		PrintWriter out = response.getWriter();
		String str="";
		if(uploadedFile.exists()) 
	    { 
			try{
			str+=TestJXL.readExcel(uploadedFile);
			uploadedFile.delete();
			out.println(str);
	        //out.println("<script>try{parent.callback('upload file success');}catch(e){};alert('"+str+"');</script>"); 
			//out.println("<script>alert('"+str+"');</script>"); 
			//request.getRequestDispatcher("success.jsp").forward(request, response);
			String url = "upexcel.jsp?excel="+str+"&bag="+bag;
			
			String strRequest = "request传值";
			String strSession = "session传值";
			request.setAttribute("strRequest", strRequest);
			request.getSession().setAttribute("strSession", strSession);
			
			request.getRequestDispatcher(url).forward(request, response);
			}catch(Exception ex){
				System.err.println("Exception:"+ex.getMessage());
				ex.printStackTrace();
				}
		}else 
	    { 
	        out.println("<script>try{parent.callback('upload file error');}catch(e){};</script>"); 
	    } 
		out.flush();
		out.close();
	}


	public File processFileUpload(HttpServletRequest request){
		File uploadedFile = null;
		//Check that we have a file upload request
		boolean isMultipart = ServletFileUpload.isMultipartContent(request);
		if(isMultipart){
			//1.-------------------------------------------------------
			//Create a factory for disk-based file items
			DiskFileItemFactory factory = new DiskFileItemFactory();
			//Set factory constraints
			factory.setSizeThreshold(maxMemorySize);
			factory.setRepository(this.tempDirectoryFile);	
			//Create a new file upload handler
			ServletFileUpload upload = new ServletFileUpload(factory);
			//Set overall request size constraint
			upload.setSizeMax(requestSizeRequestSize);
			
			//2.-------------------------------------------------------
			//Parse the request
			try {
				List items = upload.parseRequest(request);
				Iterator iter = items.iterator();
				while(iter.hasNext()){
					FileItem item = (FileItem) iter.next();
					if (!item.isFormField()) {
						//了解上传的文件
						String fileName = item.getName();
						fileName=new File(fileName).getName();
						System.out.println("recevied file,name:"+fileName);
						
						//将上传的文件保留下来【注意放病毒程序可能会在一下载完程序的时候就检查病毒并删除掉疑为病毒的文件从而导致问题，那样的话需要
						//将文件保存的目录设置为不自动检查病毒的】    
						uploadedFile = new File(this.uploadDirectoryFile,fileName);
						try {
							item.write(uploadedFile);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
					}
				}
			} catch (FileUploadException e) {
				e.printStackTrace();
			}
		}
		
		return uploadedFile;
	}

}
