package Download;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class Download extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public Download() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy();
		// Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		this.doPost(request, response);

	}

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		try {
			WritableWorkbook wwb = Workbook.createWorkbook(new File(
					"D:\\download.xls"));
			WritableSheet ws = wwb.createSheet("YouLian Sheet 1", 0);
			String[] strSession1 = (String[])request.getSession().getAttribute("testSession1"); 
			String[] strSession2 = (String[])request.getSession().getAttribute("testSession2");
			String[] strSession3 = (String[])request.getSession().getAttribute("testSession3");
			String[] strSession4 = (String[])request.getSession().getAttribute("testSession4");
			String[] strSession5 = (String[])request.getSession().getAttribute("testSession5"); 
			String[] strSession6 = (String[])request.getSession().getAttribute("testSession6");
			String[] strSession7 = (String[])request.getSession().getAttribute("testSession7");
			String[] strSession8 = (String[])request.getSession().getAttribute("testSession8");
			String[] strSession9 = (String[])request.getSession().getAttribute("testSession9"); 
			String[] strSession10 = (String[])request.getSession().getAttribute("testSession10");
			String[] strSession11 = (String[])request.getSession().getAttribute("testSession11");
			String[] strSession12 = (String[])request.getSession().getAttribute("testSession12");
			String[] strSession13 = (String[])request.getSession().getAttribute("testSession13"); 
			String[] strSession14 = (String[])request.getSession().getAttribute("testSession14");
			String[] strSession15 = (String[])request.getSession().getAttribute("testSession15");
			String[] strSession16 = (String[])request.getSession().getAttribute("testSession16");
			String[] strSession17 = (String[])request.getSession().getAttribute("testSession17"); 
			String[] strSession18 = (String[])request.getSession().getAttribute("testSession18");
			String[] strSession19 = (String[])request.getSession().getAttribute("testSession19");
			String[] strSession20 = (String[])request.getSession().getAttribute("testSession20");
			String[] strSession21 = (String[])request.getSession().getAttribute("testSession21"); 
			String[] strSession22 = (String[])request.getSession().getAttribute("testSession22");
			String[] strSession23 = (String[])request.getSession().getAttribute("testSession23");
			String[] strSession24 = (String[])request.getSession().getAttribute("testSession24");
			String[] strSession25 = (String[])request.getSession().getAttribute("testSession25");
			String[] strSession26 = (String[])request.getSession().getAttribute("testSession26");
			//PrintWriter out = response.getWriter();   
			System.out.println("<html>");  
			System.out.println("<body>");  
			System.out.println("保存到session中的内容： " + strSession1[0] + "<br>");  
			System.out.println("</body>");  
			System.out.println("</html>");
			for(int i=0;i<strSession1.length;i++){  
			    System.out.println(strSession1[i]);  
			 }
			
			Label labe1 = new Label(0, 0, "记录序号");
			ws.addCell(labe1);
			Label labe2 = new Label(1, 0, "大宗用户编号");
			ws.addCell(labe2);
			Label labe3 = new Label(2, 0, "用户自编号");
			ws.addCell(labe3);
			Label labe4 = new Label(3, 0, "寄达局邮编");
			ws.addCell(labe4);
			Label labe5 = new Label(4, 0, "寄达局名称");
			ws.addCell(labe5);
			Label labe6 = new Label(5, 0, "收件人姓名（填写英文）");
			ws.addCell(labe6);
			Label labe7 = new Label(6, 0, "英文国家名");
			ws.addCell(labe7);
			Label labe8 = new Label(7, 0, "英文州名");
			ws.addCell(labe8);
			Label labe9 = new Label(8, 0, "英文城市名");
			ws.addCell(labe9);
			Label labe10 = new Label(9, 0, "收件人地址（填写英文）");
			ws.addCell(labe10);
			Label labe11 = new Label(10, 0, "收件人电话");
			ws.addCell(labe11);
			Label labe12 = new Label(11, 0, "邮件重量");
			ws.addCell(labe12);
			Label labe13 = new Label(12, 0, "邮件号码");
			ws.addCell(labe13);
			Label labe14 = new Label(13, 0, "内件名称");
			ws.addCell(labe14);
			Label labe15 = new Label(14, 0, "内件英文名称");
			ws.addCell(labe15);
			Label labe16 = new Label(15, 0, "单件重量");
			ws.addCell(labe16);
			Label label7 = new Label(16, 0, "单价");
			ws.addCell(label7);
			Label labe18 = new Label(17, 0, "内件数量");
			ws.addCell(labe18);
			Label labe19 = new Label(18, 0, "内件类型代码（主要包括：1：礼品；2：文件；3、商品货样；4、退回物品；5、其他 ）");
			ws.addCell(labe19);
			Label labe20 = new Label(19, 0, "寄件人名称（英文）");
			ws.addCell(labe20);
			Label labe2l = new Label(20, 0, "寄件人联系电话");
			ws.addCell(labe2l);
			Label labe22 = new Label(21, 0, "寄件人地址");
			ws.addCell(labe22);
			Label labe23 = new Label(22, 0, "寄件人省名（英文）");
			ws.addCell(labe23);
			Label labe24 = new Label(23, 0, "寄件人城市名（英文）");
			ws.addCell(labe24);
			Label labe25 = new Label(24, 0, "邮件备注");
			ws.addCell(labe25);
			Label labe26 = new Label(25, 0, "运费");
			ws.addCell(labe26);
			
			for(int i=0;i<strSession1.length;i++){
			Label labelC = new Label(0, i+1, strSession1[i]);
			ws.addCell(labelC);
			Label labe2C = new Label(1, i+1, strSession2[i]);
			ws.addCell(labe2C);
			Label labe3C = new Label(2, i+1, strSession3[i]);
			ws.addCell(labe3C);
			Label labe4C = new Label(3, i+1, strSession13[i]);
			ws.addCell(labe4C);
			Label labe5C = new Label(4, i+1, strSession5[i]);
			ws.addCell(labe5C);
			Label labe6C = new Label(5, i+1, strSession6[i]);
			ws.addCell(labe6C);
			Label labe7C = new Label(6, i+1, strSession7[i]);
			ws.addCell(labe7C);
			Label labe8C = new Label(7, i+1, strSession8[i]);
			ws.addCell(labe8C);
			Label labe9C = new Label(8, i+1, strSession9[i]);
			ws.addCell(labe9C);
			Label labe10C = new Label(9, i+1, strSession10[i]);
			ws.addCell(labe10C);
			Label labe11C = new Label(10, i+1, strSession11[i]);
			ws.addCell(labe11C);
			Label labe12C = new Label(11, i+1, strSession12[i]);
			ws.addCell(labe12C);
			Label label3C = new Label(12, i+1, strSession4[i]);
			ws.addCell(label3C);
			Label labe14C = new Label(13, i+1, strSession14[i]);
			ws.addCell(labe14C);
			Label labe15C = new Label(14, i+1, strSession15[i]);
			ws.addCell(labe15C);
			Label labe16C = new Label(15, i+1, strSession16[i]);
			ws.addCell(labe16C);
			Label label7C = new Label(16, i+1, strSession17[i]);
			ws.addCell(label7C);
			Label labe18C = new Label(17, i+1, strSession18[i]);
			ws.addCell(labe18C);
			Label labe19C = new Label(18, i+1, strSession19[i]);
			ws.addCell(labe19C);
			Label labe20C = new Label(19, i+1, strSession20[i]);
			ws.addCell(labe20C);
			Label labe2lC = new Label(20, i+1, strSession21[i]);
			ws.addCell(labe2lC);
			Label labe22C = new Label(21, i+1, strSession22[i]);
			ws.addCell(labe22C);
			Label labe23C = new Label(22, i+1, strSession23[i]);
			ws.addCell(labe23C);
			Label labe24C = new Label(23, i+1, strSession24[i]);
			ws.addCell(labe24C);
			Label labe25C = new Label(24, i+1, strSession25[i]);
			ws.addCell(labe25C);
			Label labe26C = new Label(25, i+1, strSession26[i]);
			ws.addCell(labe26C);
			}
			
			/*
			 * jxl.write.WritableFont wf = new
			 * jxl.write.WritableFont(WritableFont.TIMES, 18, WritableFont.BOLD,
			 * true); jxl.write.WritableCellFormat wcfF = new
			 * jxl.write.WritableCellFormat(wf); jxl.write.Label labelCF = new
			 * jxl.write.Label(1, 0, "This is a Label Cell", wcfF);
			 * ws.addCell(labelCF);
			 */

			/*
			 * jxl.write.WritableFont wfc = new
			 * jxl.write.WritableFont(WritableFont.ARIAL, 10,
			 * WritableFont.NO_BOLD, false, UnderlineStyle.NO_UNDERLINE,
			 * jxl.format.Colour.RED); jxl.write.WritableCellFormat wcfFC = new
			 * jxl.write.WritableCellFormat(wfc); jxl.write.Label labelCFC = new
			 * jxl.write.Label(1, 0, "This is a Label Cell", wcfFC);
			 * ws.addCell(labelCF);
			 */

			/*
			 * jxl.write.Number labelN = new jxl.write.Number(0, 1, 3.1415926);
			 * ws.addCell(labelN);
			 */

			/*
			 * jxl.write.NumberFormat nf = new jxl.write.NumberFormat("#.##");
			 * jxl.write.WritableCellFormat wcfN = new
			 * jxl.write.WritableCellFormat(nf); jxl.write.Number labelNF = new
			 * jxl.write.Number(1, 1, 3.1415926, wcfN); ws.addCell(labelNF);
			 */

			/*
			 * jxl.write.Boolean labelB = new jxl.write.Boolean(0, 2, false);
			 * ws.addCell(labelB);
			 */

			/*
			 * jxl.write.DateTime labelDT = new jxl.write.DateTime(0, 3, new
			 * java.util.Date()); ws.addCell(labelDT);
			 */

			/*
			 * jxl.write.DateFormat df = new jxl.write.DateFormat("dd MM yyyy
			 * hh:mm:ss"); jxl.write.WritableCellFormat wcfDF = new
			 * jxl.write.WritableCellFormat(df); jxl.write.DateTime labelDTF =
			 * new jxl.write.DateTime(1, 3, new java.util.Date(), wcfDF);
			 * ws.addCell(labelDTF);
			 */

			wwb.write();
			wwb.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.sendRedirect("/dts.jsp");
	}

	/**
	 * Initialization of the servlet. <br>
	 * 
	 * @throws ServletException
	 *             if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}

