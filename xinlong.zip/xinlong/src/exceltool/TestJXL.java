package exceltool;

import java.io.File;
import com.DBCon;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import sun.org.mozilla.javascript.internal.ast.NewExpression;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class TestJXL {
	static File file=new File("D:\\excel\\a.xls");
	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {
		readExcel(file);
	}

	public static String readExcel(File file) throws SQLException {
		StringBuffer buf=new StringBuffer("");
		try {
			Workbook book = Workbook.getWorkbook(file);
			Sheet sheet = book.getSheet(0);
			int rownum = sheet.getRows();
			int colnum = sheet.getColumns();
			DBCon dbCommCon = new DBCon();
			dbCommCon.getConnection();
			String SqlMailDetail= "";
			if (rownum != 0) {
				for (int j = 0; j < rownum; j++) {
					SqlMailDetail= "insert into upexcel(record_num,usernum,selfnum,yj_code,jdjname,sj_name,sj_countryname,sj_statename,sj_cityname,sj_address,sj_tel,yj_weight,jdjcode,nj_enname,nj_name,dj_weight,price,nj_num,nj_type,jj_name,jj_tel,jj_address,jj_province,jj_cityname,remark) values(";
					for (int i = 0; i < colnum; i++){
						Cell cell = sheet.getCell(i, j);
						String content = cell.getContents();
						if(j==0){
							if(content==""){
								//content="test";
								colnum=i;
								break;
							}
						}else{
							if(content==""){
								if(i==1)return buf.toString();
								content="null";
								//colnum=i;
								//break;
							}
							if(content.indexOf("'")>-1){
								  //有单引号
								content=content.replace("'", "\\'") ; 
								  //out.println(str);
							}
							if(i == 12)//"邮件号码"
							{
								String sql="select * from upexcel where jdjcode='"+content+"' or selfnum='"+content+"'";
								ResultSet rs=dbCommCon.selectRecord(sql);
								if(rs.next()){
									buf.append(content);
									buf.append(",");
									continue;
									//return content;
								}
							}

							if(i < colnum-1)
								SqlMailDetail = SqlMailDetail + "'" + content + "',";
							else
								SqlMailDetail = SqlMailDetail + "'" + content + "')";
						}
					}
					System.out.println(SqlMailDetail);
					if(j>0)
					{
						dbCommCon.insertRecord(SqlMailDetail);
					}
							
					//buf.append("|");
				}
			}
			dbCommCon.closeConn();
		} catch (BiffException e) {
			e.printStackTrace();
		} catch (IndexOutOfBoundsException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return buf.toString();
		//return "";
	}
}