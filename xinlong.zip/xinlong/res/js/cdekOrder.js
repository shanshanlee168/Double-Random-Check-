﻿
var XMLHttpReq;
    function createXMLHttpRequest() {
		if(window.XMLHttpRequest) { //Mozilla 浏览器
			XMLHttpReq = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) { // IE浏览器
			try {
				XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}
	}

	function update_order() {	
		
		var order_Number = document.getElementById("order_Number").value;
		var goods_weight = document.getElementById("goods_weight").value*1000;
		var goods_length = document.getElementById("goods_length").value*10;
		var goods_width = document.getElementById("goods_width").value*10;
		var goods_height = document.getElementById("goods_height").value*10;
		var city_Code = document.getElementById("dst_post").value;
		var dst_address = document.getElementById("dst_address").value;
		var dst_name = document.getElementById("dst_name").value;
		var dst_number = document.getElementById("dst_number").value;
		
		var url ="http://www.std-express.com:8989/rc_getNewOrder.php?order_Number="
			+order_Number+"&goods_weight="+goods_weight+"&goods_length="+goods_length+
			"&goods_width="+goods_width+"&goods_height="+goods_height+"&city_Code="+city_Code+
			"&dst_address="+dst_address+"&dst_name="+dst_name+"&dst_number="+dst_number;
	       
		createXMLHttpRequest();
	       XMLHttpReq.open("GET",url,true);
	       XMLHttpReq.onreadystatechange = callhandle;
	       XMLHttpReq.send(null); // 发送请求   
	}

    function send()
    {
       var sendOrder="401029401470";
       var url = "http://www.std-express.com:8989/rc_getTraking.php?orderName="+sendOrder;
       
       createXMLHttpRequest();
       XMLHttpReq.open("GET",url,true);
       XMLHttpReq.onreadystatechange = callhandle;
       XMLHttpReq.send(null); // 发送请求   
       alert('test');
       
    }
// ajax.js  
    function callhandle()
    {
    	alert('test1');
    	if (XMLHttpReq.readyState == 4) {  
            alert(XMLHttpReq.status);  
            alert(XMLHttpReq.responseText);  
            if (XMLHttpReq.status == 200) {  
                alert("200");  
            } else {  
                alert(XMLHttpReq.status);  
                alert("Problem retrieving XML data");  
            }  
        }
    }
    
