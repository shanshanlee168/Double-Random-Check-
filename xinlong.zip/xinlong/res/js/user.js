$(document).ready(function() {
    FastClick.attach(document.body);
    
    $("#logout").on("click", function(a) {
        top.location.href = "/logout.do";
    });
});
