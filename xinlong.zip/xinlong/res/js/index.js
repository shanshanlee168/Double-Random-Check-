$(document).ready(function() {
    FastClick.attach(document.body);

    $("#weixin-oauth").on("click", function(a) {
        a.preventDefault();
        top.location.href = "/user.do";
    });
    $("#weixin-pay").on("click", function(a) {
        a.preventDefault();
        top.location.href = "/pay_mock.do";
    });
});
