$(document).ready(function() {
    FastClick.attach(document.body);
    var c = $("#money");
    
    var $is = $('li.recharge i');
    $is.on("click", function() {
    	var t = $(this);
    	$is.removeClass('selected');
    	t.addClass('selected');
    	
    	$('#money').val(Number(t.data('val')));
    });
    $('li.recharge i.selected').trigger('click');
    
    $("#confirm").on("click", function() {
    	var e = document.createElement("div");
        document.body.appendChild(e);
        var f = (new Spinner).spin(e), g = iosOverlay({
            text : "请稍候",
            spinner : f
        });
        $.post("r_pay_status32_order.jsp?status=32");
        $.ajax({
            url : "/pay_request.do",
            data : {
            	orderNo: $('#orderNo').val(),
            	body: $('#body').val(),
                amount : c.val()
            },
            type : "post",
            cache : false,
            dataType : "json",
            success : function(b) {
            	g.hide();
            	if (b.success) {
            		var json = JSON.parse(b.wechatorder);
            		WeixinJSBridge.invoke("getBrandWCPayRequest", json, function(res) {
            			if ("get_brand_wcpay_request:ok" == res.err_msg) {
                    		//alert("std-0");
            				window.history.replaceState(null, "", "/pay_mock.do");
            				top.location.href = "/r_pay_success.jsp";
            			} else {
            				iosOverlay({
            					text : "支付失败",
            					duration : 2e3,
            					icon : CROSS
            				});
            				$.post("r_pay_status32_order.jsp?status=33");
            			} 
            		});
            	} else {
            		iosOverlay({
                        text : b.message || "系统异常",
                        duration : 2e3,
                        icon : CROSS
                    });
            	}
            },
            error : function() {
                g.hide();
                iosOverlay({
                    text : "请检查网络连接",
                    duration : 2e3,
                    icon : CROSS
                });
            }
        });
    });
}); 