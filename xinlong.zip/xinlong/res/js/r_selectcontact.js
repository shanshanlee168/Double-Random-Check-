﻿
var XMLHttpReq;
    function createXMLHttpRequest() {
		if(window.XMLHttpRequest) { //Mozilla 浏览器
			XMLHttpReq = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) { // IE浏览器
			try {
				XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}
	}

// ajax.js  
  
var inputField;  
var completeBody;
var conutryFlag;

function findNames(openid,name,country) {          	   
    inputField = document.getElementById("searchInput");            
    completeBody = document.getElementById("searchResult");
    conutryFlag = country;
      if (inputField.value.length >= 0) {   
            var o=createXMLHttpRequest();       
            	/*if (inputField.value.length < 2)
            		{
            		clearNames(); return;
            		}*/
                var url = "searchDstContact.jsp?openid="+openid+"&name="+name+"&country="+country;
                //alert(url);
                //此处escape函数可以去掉，escape是采用ISO Latin字符集对指定的字符串进行编码。   
                            XMLHttpReq.open("GET", url, true);   
            XMLHttpReq.onreadystatechange = function(){  
		     if (XMLHttpReq.readyState == 4) { // 判断对象状态  
		          if (XMLHttpReq.status == 200) { // 信息已经成功返回，开始处理信息   
		                  setNames(XMLHttpReq.responseXML.getElementsByTagName("res"),XMLHttpReq.responseXML.getElementsByTagName("keyPhone"));  
		          }else { //页面不正常   
		             // window.alert("Something wrong happend!");   
		          }   
		      }   
		  
		};//指定响应函数   
            XMLHttpReq.send(null); // 发送请求   
      } else {   
            clearNames();   
      }   
}   
  
//生成与输入内容匹配行  
function setNames(names,phones) {             
      clearNames();  
      var size = names.length;  

      var row, cell,childc, txtNode;  
      for (var i = 0; i < size; i++) {  
          var nextNode = names[i].firstChild.data+"  "+phones[i].firstChild.data;  

          row = document.createElement("div");  
          row.setAttribute("class", "weui-cell weui-cell_access");
          cell = document.createElement("div");      
          cell.setAttribute("class", "weui-cell__bd weui-cell_primary");
          childc = document.createElement("p");      
          childc.onclick = function() {  
              completeField(this);  
          } ;  
          txtNode = document.createTextNode(nextNode);  
          childc.appendChild(txtNode);  
          cell.appendChild(childc);  
          row.appendChild(cell);  
          completeBody.appendChild(row);  
      }  
}

//填写输入框  
function completeField(cell) {
	
	inputField.value = cell.firstChild.nodeValue;
	var names = XMLHttpReq.responseXML.getElementsByTagName("res");
	var keyPhone = XMLHttpReq.responseXML.getElementsByTagName("keyPhone");
	var keyProvince = XMLHttpReq.responseXML.getElementsByTagName("keyProvince");
	var keyCity = XMLHttpReq.responseXML.getElementsByTagName("keyCity");
	var keyAddress = XMLHttpReq.responseXML.getElementsByTagName("keyAddress");
	var keyPost = XMLHttpReq.responseXML.getElementsByTagName("keyPost");
	var size = names.length;
	var backName = "";
	for (var i = 0; i < size; i++) {
		var nextNode = names[i].firstChild.data+"  "+keyPhone[i].firstChild.data;
		if (inputField.value == nextNode) {
			backName = names[i].firstChild.data;
			var provinceCode="",postCode="";
			if(keyProvince[i].firstChild != null)provinceCode = keyProvince[i].firstChild.data;
			if(keyPost[i].firstChild != null)postCode = keyPost[i].firstChild.data;
			// alert(backName);
			inputField.value = backName;
			if(conutryFlag == "5")
				{
				self.location="r_selectuser.jsp?country="+conutryFlag+
				"&srcName=999123456&dstName="+backName+"&dstCity="+keyCity[i].firstChild.data+"&dstAddress="+
				keyAddress[i].firstChild.data+"&dstPhone="+keyPhone[i].firstChild.data+"&dstProvince="+
				provinceCode+"&dstCode="+postCode;
				}
			else if(conutryFlag == "6")
				{
				self.location="ru_selectuser.jsp?country="+conutryFlag+
				"&srcName=999123456&dstName="+backName+"&dstCity="+keyCity[i].firstChild.data+"&dstAddress="+
				keyAddress[i].firstChild.data+"&dstPhone="+keyPhone[i].firstChild.data+"&dstProvince="+
				provinceCode+"&dstCode="+postCode;
				}
			else
				{
				self.location="r_select_hask_user.jsp?country="+conutryFlag+
				"&srcName=999123456&dstName="+backName+"&dstCity="+keyCity[i].firstChild.data+"&dstAddress="+
				keyAddress[i].firstChild.data+"&dstPhone="+keyPhone[i].firstChild.data+"&dstProvince="+
				provinceCode+"&dstCode="+postCode;
				}

			break;
		}
	}
	clearNames();
}  

// 清除自动完成行
function clearNames() {  
      var ind = completeBody.childNodes.length;  
      for (var i = ind - 1; i >= 0 ; i--) {  
          completeBody.removeChild(completeBody.childNodes[i]);  
      }  
}

