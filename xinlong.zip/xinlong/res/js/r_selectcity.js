﻿
var XMLHttpReq;
    function createXMLHttpRequest() {
		if(window.XMLHttpRequest) { //Mozilla 浏览器
			XMLHttpReq = new XMLHttpRequest();
		}
		else if (window.ActiveXObject) { // IE浏览器
			try {
				XMLHttpReq = new ActiveXObject("Msxml2.XMLHTTP");
			} catch (e) {
				try {
					XMLHttpReq = new ActiveXObject("Microsoft.XMLHTTP");
				} catch (e) {}
			}
		}
	}

// ajax.js  
  
var completeDiv;  
var inputField;  
var inputField1;  
var completeTable;  
var completeBody;
var city_flag;
function findNames(flag) {   
	city_flag = flag;
    inputField = document.getElementById("fdstprovince");            
    inputField1 = document.getElementById("fdstCity");            
       completeTable = document.getElementById("complete_table");   
       completeDiv = document.getElementById("popup");  
       //alert(completeDiv.val());	 
       	   
       completeBody = document.getElementById("complete_body");   
      if (inputField.value.length > 0) {   
            var o=createXMLHttpRequest();       
            if(city_flag == "0")
            	{
                var url = "searchProvince.jsp?names=" + inputField.value;  
              //此处escape函数可以去掉，escape是采用ISO Latin字符集对指定的字符串进行编码。   
                          XMLHttpReq.open("GET", url, true);   
            	}
            else
            	{
            	if (inputField1.value.length < 2)
            		{
            		clearNames(); return;
            		}
                var url = "searchCity.jsp?province="+inputField.value + "&names="+inputField1.value;
                //alert(url);
                //此处escape函数可以去掉，escape是采用ISO Latin字符集对指定的字符串进行编码。   
                            XMLHttpReq.open("GET", url, true);   
            	}
            XMLHttpReq.onreadystatechange = function(){  
		     if (XMLHttpReq.readyState == 4) { // 判断对象状态  
		          if (XMLHttpReq.status == 200) { // 信息已经成功返回，开始处理信息   
		                  setNames(XMLHttpReq.responseXML.getElementsByTagName("res"));  
		          }else { //页面不正常   
		             // window.alert("Something wrong happend!");   
		          }   
		      }   
		  
		};//指定响应函数   
            XMLHttpReq.send(null); // 发送请求   
      } else {   
            clearNames();   
      }   
}   
  
//生成与输入内容匹配行  
function setNames(names) {             
      clearNames();  
      var size = names.length;  
      setOffsets();  
      var row, cell, txtNode;  
      for (var i = 0; i < size; i++) {  
          var nextNode = names[i].firstChild.data;  
          row = document.createElement("tr");  
          cell = document.createElement("td");      
          cell.onmouseout = function() {  
              this.className='mouseOver';  
          };  
          cell.onmouseover = function() {  
              this.className='mouseOut';  
          };  
          cell.setAttribute("bgcolor", "#ffffff");  
          cell.setAttribute("border", "1");  
          if(city_flag == "0")
        	  cell.setAttribute("width",inputField.offsetWidth+"px"); 
          else
        	  cell.setAttribute("width",inputField1.offsetWidth+"px");
          cell.onclick = function() {  
              completeField(this);  
          } ;  
          txtNode = document.createTextNode(nextNode);  
          cell.appendChild(txtNode);  
          row.appendChild(cell);  
          completeBody.appendChild(row);  
      }  
}
  
//设置显示位置                  
function setOffsets() {  
      completeTable.style.width = "auto";    //显示自动完成的提示框宽度自动伸展或缩小  
      if(city_flag == "0")
    	  gettable(inputField);  
      else
    	  gettable(inputField1);
}  
//取绝对位置  
function getAbsPosition(obj) {  
    var r = {  
        left: obj.offsetLeft,  
        top : obj.offsetTop  
    };  
    r.left = obj.offsetLeft;  
    r.top  = obj.offsetTop;  
    if(obj.offsetParent) {  
        var tmp = getAbsPosition(obj.offsetParent);  
        r.left += tmp.left;  
        r.top  += tmp.top;  
    }  
    return r;  
  }  
  //为提示定位  
function gettable(obj) {  
    var pos = getAbsPosition(obj);  
    pos.top += obj.offsetHeight;  
    completeDiv.style.top = pos.top + "px";  
    completeDiv.style.left = pos.left + "px";  
    completeDiv.style.width = obj.offsetWidth + "px";  
    completeDiv.style.visibility = '';  
  }  
  
//计算显示位置  
function calculateOffset(field, attr) {  
      var offset = 0;  
      while(field) {  
          offset += field[attr];  
          fieldfield = field.offsetParent;  
      }  
      return offset;  
}  
  
//填写输入框  
function completeField(cell) {
	if(city_flag == "0")
		{
	      inputField.value = cell.firstChild.nodeValue; 
		}
	else
	{
	      inputField1.value = cell.firstChild.nodeValue; 
	  	var names =XMLHttpReq.responseXML.getElementsByTagName("res");
	  	var keyCode =XMLHttpReq.responseXML.getElementsByTagName("keyCode");
	      var size = names.length;  
	  	var backName ="";
	     for (var i = 0; i < size; i++) {  
	  	var nextNode = names[i].firstChild.data;
	  	if(inputField1.value == nextNode)
	  		{
	  			backName = keyCode[i].firstChild.data;
	  			//alert(backName); 
	  			document.getElementById("dst_Code").value=backName;
	  			
	  			break;
	  		}
	  	}
	}
      clearNames();  
	 // alert(inputField.value); 
	 /* var e = jQuery.Event("keypress");//模拟一个键盘事件
            e.keyCode = 13;//keyCode=27 ESC
            $(window).trigger(e);//模拟页码框按下回车 */
      /*
	var names =XMLHttpReq.responseXML.getElementsByTagName("res");
	var backCN =XMLHttpReq.responseXML.getElementsByTagName("keyCN");
       var size = names.length;  
	var backName ="";
      for (var i = 0; i < size; i++) {  
	var nextNode = names[i].firstChild.data;
	if(inputField.value == nextNode)
		{
			backName = backCN[i].firstChild.data;break;
		}
	}
*/
            
	//alert(backName);
 	//var responseValue = XMLHttpReq.responseText;

/*	if(backName == "NULL")
		self.location = "ListGoods?search_key="+inputField.value +"&page.x=7&page.y=13&page=0";
	else
		self.location = "ListGoods?search_key="+backName +"&page.x=7&page.y=13&page=0";*/
}  
  
//清除自动完成行  
function clearNames() {  
      var ind = completeBody.childNodes.length;  
      for (var i = ind - 1; i >= 0 ; i--) {  
          completeBody.removeChild(completeBody.childNodes[i]);  
      }  
      completeDiv.style.border = "none";  
}
